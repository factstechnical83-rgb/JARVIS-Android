package com.example.viewmodel

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AssistantState
import com.example.audio.VoiceManager
import com.example.automation.ActionResult
import com.example.automation.ActionType
import com.example.automation.JarvisActionManager
import com.example.data.ChatMessage
import com.example.data.GeminiService
import com.example.data.JarvisPreferences
import com.example.data.Sender
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    val preferences = JarvisPreferences(application)
    private val geminiService = GeminiService(preferences)
    val voiceManager = VoiceManager(application, preferences)
    val actionManager = JarvisActionManager(application)

    val assistantState: StateFlow<AssistantState> = voiceManager.assistantState
    val audioRms: StateFlow<Float> = voiceManager.audioRms
    val partialSpeechText: StateFlow<String> = voiceManager.partialSpeechText
    val isWakeWordActive: StateFlow<Boolean> = voiceManager.isWakeWordActive
    val isWakeWordListening: StateFlow<Boolean> = voiceManager.isWakeWordListening

    private val _chatHistory = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = Sender.JARVIS,
                text = "नमस्ते सर! मैं जार्विस हूँ, आपकी महिला एआई सहायक। 'Hey Jarvis' बोलें या माइक दबाएँ—मैं हमेशा तैयार हूँ!"
            )
        )
    )
    val chatHistory: StateFlow<List<ChatMessage>> = _chatHistory.asStateFlow()

    private val _latestUserPrompt = MutableStateFlow("")
    val latestUserPrompt: StateFlow<String> = _latestUserPrompt.asStateFlow()

    private val _latestJarvisResponse = MutableStateFlow("नमस्ते सर! मैं जार्विस हूँ। 'Hey Jarvis' या 'Hello Jarvis' बोलकर तुरंत बात करें!")
    val latestJarvisResponse: StateFlow<String> = _latestJarvisResponse.asStateFlow()

    private val _lastExecutedAction = MutableStateFlow<ActionResult?>(null)
    val lastExecutedAction: StateFlow<ActionResult?> = _lastExecutedAction.asStateFlow()

    private val _isSettingsOpen = MutableStateFlow(false)
    val isSettingsOpen: StateFlow<Boolean> = _isSettingsOpen.asStateFlow()

    private val _isConversationHistoryOpen = MutableStateFlow(false)
    val isConversationHistoryOpen: StateFlow<Boolean> = _isConversationHistoryOpen.asStateFlow()

    private val _hasApiKey = MutableStateFlow(preferences.getEffectiveApiKey().isNotBlank())
    val hasApiKey: StateFlow<Boolean> = _hasApiKey.asStateFlow()

    init {
        if (preferences.wakeWordEnabled) {
            startWakeWordListening()
        }
    }

    fun startWakeWordListening() {
        voiceManager.startWakeWordDetection { trailingCommand ->
            handleWakeWordTriggered(trailingCommand)
        }
    }

    fun stopWakeWordListening() {
        voiceManager.stopWakeWordDetection()
    }

    fun toggleWakeWord() {
        if (isWakeWordActive.value) {
            stopWakeWordListening()
        } else {
            startWakeWordListening()
        }
    }

    private fun handleWakeWordTriggered(trailingCommand: String) {
        if (trailingCommand.isNotBlank()) {
            // User spoke both wake word and command in one breath: "Hey Jarvis open camera"
            processUserQuery(trailingCommand)
        } else {
            // User only called the wake word: "Hey Jarvis" / "Hello Jarvis"
            val wakeUserMsg = ChatMessage(sender = Sender.USER, text = "Hey Jarvis!")
            _latestUserPrompt.value = "Hey Jarvis!"
            _chatHistory.value = _chatHistory.value + wakeUserMsg

            val wakeReplies = listOf(
                "हाँ जी सर! मैं सुन रही हूँ, बताइए क्या काम है?",
                "नमस्ते सर! मैं हाज़िर हूँ, आदेश दीजिए।",
                "जी सर, कहिए! मैं सुन रही हूँ।"
            )
            val chosenReply = wakeReplies.random()
            _latestJarvisResponse.value = chosenReply
            val wakeJarvisMsg = ChatMessage(sender = Sender.JARVIS, text = chosenReply)
            _chatHistory.value = _chatHistory.value + wakeJarvisMsg

            // Respond immediately in realistic female voice, then open active listening for command!
            voiceManager.speak(chosenReply) {
                startVoiceInput()
            }
        }
    }

    fun onMicClicked() {
        when (assistantState.value) {
            AssistantState.SPEAKING -> {
                voiceManager.stopSpeaking()
            }
            AssistantState.LISTENING -> {
                voiceManager.stopListening()
            }
            AssistantState.PROCESSING -> {
                // Do nothing while processing
            }
            AssistantState.STANDBY -> {
                startVoiceInput()
            }
        }
    }

    fun startVoiceInput() {
        voiceManager.startListening { spokenText ->
            processUserQuery(spokenText)
        }
    }

    fun processUserQuery(query: String) {
        if (query.isBlank()) return

        _latestUserPrompt.value = query
        val userMsg = ChatMessage(sender = Sender.USER, text = query)
        _chatHistory.value = _chatHistory.value + userMsg

        voiceManager.setProcessingState()

        // 1. First priority: Check if it's an actionable A-to-Z command
        val actionResult = actionManager.processCommand(query)
        if (actionResult.handled) {
            _lastExecutedAction.value = actionResult
            _latestJarvisResponse.value = actionResult.spokenResponse
            val jarvisMsg = ChatMessage(sender = Sender.JARVIS, text = actionResult.spokenResponse)
            _chatHistory.value = _chatHistory.value + jarvisMsg

            // Launch the associated intent if present
            if (actionResult.intentToLaunch != null) {
                try {
                    val app = getApplication<Application>()
                    actionResult.intentToLaunch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    app.startActivity(actionResult.intentToLaunch)
                } catch (_: Throwable) {}
            }

            // Speak response in female Hindi voice
            voiceManager.speak(actionResult.spokenResponse) {
                if (actionResult.actionType == ActionType.WAKE_GREETING || preferences.autoListenHandsFree) {
                    startVoiceInput()
                }
            }
            return
        }

        // 2. Fallback to Gemini AI for knowledge, conversation and complex requests
        viewModelScope.launch {
            val result = geminiService.generateResponse(query, _chatHistory.value)
            val replyText = result.getOrElse {
                "माफ़ कीजियेगा सर, उत्तर प्राप्त करने में समस्या हुई। कृपया दोबारा प्रयास करें।"
            }

            _latestJarvisResponse.value = replyText
            val jarvisMsg = ChatMessage(sender = Sender.JARVIS, text = replyText)
            _chatHistory.value = _chatHistory.value + jarvisMsg

            // Real audio-to-audio: Speak output aloud immediately in realistic Hindi female voice
            voiceManager.speak(replyText) {
                if (preferences.autoListenHandsFree) {
                    startVoiceInput()
                }
            }
        }
    }

    fun triggerActionAgain() {
        val action = _lastExecutedAction.value ?: return
        if (action.intentToLaunch != null) {
            try {
                val app = getApplication<Application>()
                action.intentToLaunch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                app.startActivity(action.intentToLaunch)
            } catch (_: Throwable) {}
        }
    }

    fun executeQuickApp(name: String) {
        processUserQuery("open $name")
    }

    fun sendWhatsAppDirect(text: String, phone: String = "") {
        val cmd = if (phone.isNotBlank()) {
            "whatsapp $phone message $text"
        } else {
            "whatsapp message $text"
        }
        processUserQuery(cmd)
    }

    fun replayAudio(text: String) {
        voiceManager.speak(text)
    }

    fun stopSpeaking() {
        voiceManager.stopSpeaking()
    }

    fun openSettings() {
        _isSettingsOpen.value = true
    }

    fun closeSettings() {
        _isSettingsOpen.value = false
    }

    fun toggleConversationHistory() {
        _isConversationHistoryOpen.value = !_isConversationHistoryOpen.value
    }

    fun clearChatHistory() {
        _chatHistory.value = listOf(
            ChatMessage(
                sender = Sender.JARVIS,
                text = "नमस्ते सर! सिस्टम मेमोरी रीसेट कर दी गई है। मैं नई बातचीत के लिए तैयार हूँ।"
            )
        )
        _latestUserPrompt.value = ""
        _latestJarvisResponse.value = "सिस्टम मेमोरी रीसेट कर दी गई है। मैं तैयार हूँ।"
        voiceManager.stopSpeaking()
    }

    fun saveSettings(apiKey: String, autoListen: Boolean, wakeWord: Boolean, pitch: Float, speed: Float) {
        preferences.customApiKey = apiKey
        preferences.autoListenHandsFree = autoListen
        preferences.wakeWordEnabled = wakeWord
        preferences.voicePitch = pitch
        preferences.voiceSpeed = speed
        voiceManager.setupHindiFemaleVoice()
        _hasApiKey.value = preferences.getEffectiveApiKey().isNotBlank()

        if (wakeWord) {
            startWakeWordListening()
        } else {
            stopWakeWordListening()
        }

        closeSettings()
    }

    fun testVoice(text: String = "नमस्ते! मैं जार्विस हूँ। यह मेरी सजीव महिला हिंदी आवाज़ है। क्या यह आपको पसंद आई?") {
        voiceManager.speak(text)
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.destroy()
    }
}
