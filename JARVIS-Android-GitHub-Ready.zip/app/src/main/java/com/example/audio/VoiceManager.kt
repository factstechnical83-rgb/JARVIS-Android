package com.example.audio

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.example.data.JarvisPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

enum class AssistantState {
    STANDBY,
    LISTENING,
    PROCESSING,
    SPEAKING
}

data class WakeWordMatch(
    val matchedWakeWord: String,
    val trailingCommand: String
)

class VoiceManager(
    private val context: Context,
    private val preferences: JarvisPreferences
) : TextToSpeech.OnInitListener {

    private val scope = CoroutineScope(Dispatchers.Main + Job())

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false
    private var isDestroyed = false

    private val _assistantState = MutableStateFlow(AssistantState.STANDBY)
    val assistantState: StateFlow<AssistantState> = _assistantState.asStateFlow()

    private val _audioRms = MutableStateFlow(0f)
    val audioRms: StateFlow<Float> = _audioRms.asStateFlow()

    private val _partialSpeechText = MutableStateFlow("")
    val partialSpeechText: StateFlow<String> = _partialSpeechText.asStateFlow()

    private val _isWakeWordActive = MutableStateFlow(preferences.wakeWordEnabled)
    val isWakeWordActive: StateFlow<Boolean> = _isWakeWordActive.asStateFlow()

    private val _isWakeWordListening = MutableStateFlow(false)
    val isWakeWordListening: StateFlow<Boolean> = _isWakeWordListening.asStateFlow()

    private var onSpeechResultCallback: ((String) -> Unit)? = null
    private var onSpeakingCompletedCallback: (() -> Unit)? = null
    private var onWakeWordCallback: ((trailingCommand: String) -> Unit)? = null

    private var isCurrentlyInWakeWordMode = false
    private var isCurrentlySpeaking = false
    private var wakeWordRestartJob: Job? = null
    private var simulatedSpeechPulseJob: Job? = null

    private val wakeWordPhrases = listOf(
        "hey jarvis",
        "hello jarvis",
        "hi jarvis",
        "ok jarvis",
        "hey jarvish",
        "hello jarvish",
        "hey javish",
        "hello javish",
        "हे जार्विस",
        "हेलो जार्विस",
        "हाय जार्विस",
        "नमस्ते जार्विस",
        "सुनो जार्विस",
        "जार्विस सुनो",
        "जार्विस",
        "jarvis"
    )

    init {
        initializeTts()
        initializeRecognizer()
    }

    private fun initializeTts() {
        textToSpeech = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            setupHindiFemaleVoice()
        }
    }

    fun setupHindiFemaleVoice() {
        val tts = textToSpeech ?: return

        // 1. Language Setup: hi-IN preferred, fallback to hi, then en-IN
        val hindiLocale = Locale.Builder().setLanguage("hi").setRegion("IN").build()
        var langResult = tts.setLanguage(hindiLocale)
        if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            langResult = tts.setLanguage(Locale.Builder().setLanguage("hi").build())
        }
        if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.setLanguage(Locale.Builder().setLanguage("en").setRegion("IN").build())
        }

        // 2. Realistic Female Voice Selection
        try {
            val voices = tts.voices
            if (!voices.isNullOrEmpty()) {
                val relevantVoices = voices.filter { v ->
                    val lang = v.locale.language.lowercase(Locale.ROOT)
                    lang == "hi" || (lang == "en" && v.locale.country.equals("IN", ignoreCase = true))
                }

                // Look for Google's ultra-realistic neural/network female Hindi voice first
                val selectedVoice = relevantVoices.firstOrNull { v ->
                    val name = v.name.lowercase(Locale.ROOT)
                    v.locale.language == "hi" &&
                        (name.contains("network") || v.isNetworkConnectionRequired) &&
                        (name.contains("hie") || name.contains("hid") || name.contains("fem"))
                } ?: relevantVoices.firstOrNull { v ->
                    val name = v.name.lowercase(Locale.ROOT)
                    v.locale.language == "hi" &&
                        (name.contains("hie") || name.contains("hid") || name.contains("hia") || name.contains("fem") || name.contains("female"))
                } ?: relevantVoices.firstOrNull { v ->
                    val name = v.name.lowercase(Locale.ROOT)
                    name.contains("female") || name.contains("fem") || v.features.any { it.contains("female", ignoreCase = true) }
                } ?: relevantVoices.firstOrNull { v ->
                    v.locale.language == "hi"
                } ?: voices.firstOrNull { it.name.lowercase(Locale.ROOT).contains("female") }

                if (selectedVoice != null) {
                    tts.voice = selectedVoice
                }
            }
        } catch (_: Throwable) {
            // Use default voice
        }

        // Apply realistic female voice pitch and natural cadence
        tts.setPitch(preferences.voicePitch)
        tts.setSpeechRate(preferences.voiceSpeed)

        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                isCurrentlySpeaking = true
                scope.launch {
                    _assistantState.value = AssistantState.SPEAKING
                    startSimulatedSpeechAudioWave()
                }
            }

            override fun onDone(utteranceId: String?) {
                isCurrentlySpeaking = false
                scope.launch {
                    simulatedSpeechPulseJob?.cancel()
                    _audioRms.value = 0f
                    _assistantState.value = AssistantState.STANDBY
                    onSpeakingCompletedCallback?.invoke()

                    // Resume wake word listening if enabled
                    if (_isWakeWordActive.value && !isDestroyed) {
                        scheduleWakeWordRestart(500)
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                isCurrentlySpeaking = false
                scope.launch {
                    simulatedSpeechPulseJob?.cancel()
                    _audioRms.value = 0f
                    _assistantState.value = AssistantState.STANDBY

                    if (_isWakeWordActive.value && !isDestroyed) {
                        scheduleWakeWordRestart(500)
                    }
                }
            }
        })
    }

    private fun initializeRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    if (isCurrentlyInWakeWordMode) {
                        _isWakeWordListening.value = true
                    } else {
                        _assistantState.value = AssistantState.LISTENING
                        _partialSpeechText.value = ""
                    }
                }

                override fun onBeginningOfSpeech() {
                    if (!isCurrentlyInWakeWordMode) {
                        _assistantState.value = AssistantState.LISTENING
                    }
                }

                override fun onRmsChanged(rmsdB: Float) {
                    val normalized = ((rmsdB + 2f) / 12f).coerceIn(0.05f, 1f)
                    _audioRms.value = normalized
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {
                    _audioRms.value = 0f
                }

                override fun onError(error: Int) {
                    _audioRms.value = 0f
                    if (isCurrentlyInWakeWordMode) {
                        _isWakeWordListening.value = false
                        // Standard timeouts or no matches in wake word mode are expected: restart seamlessly
                        if (_isWakeWordActive.value && !isCurrentlySpeaking && !isDestroyed) {
                            scheduleWakeWordRestart(400)
                        }
                    } else {
                        _assistantState.value = AssistantState.STANDBY
                        if (_isWakeWordActive.value && !isCurrentlySpeaking && !isDestroyed) {
                            scheduleWakeWordRestart(600)
                        }
                    }
                }

                override fun onResults(results: Bundle?) {
                    _audioRms.value = 0f
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spoken = matches?.firstOrNull()?.trim() ?: ""
                    _partialSpeechText.value = ""

                    if (isCurrentlyInWakeWordMode) {
                        _isWakeWordListening.value = false
                        val wakeMatch = checkWakeWord(spoken)
                        if (wakeMatch != null) {
                            // Wake word detected! Play activation chime & haptic feedback
                            playWakeChimeAndVibrate()
                            isCurrentlyInWakeWordMode = false
                            _assistantState.value = AssistantState.PROCESSING
                            onWakeWordCallback?.invoke(wakeMatch.trailingCommand)
                        } else {
                            // Spoken text did not contain wake word, resume waiting for Hey Jarvis
                            if (_isWakeWordActive.value && !isCurrentlySpeaking && !isDestroyed) {
                                scheduleWakeWordRestart(350)
                            }
                        }
                    } else {
                        // Active voice input mode
                        if (spoken.isNotBlank()) {
                            _assistantState.value = AssistantState.PROCESSING
                            // Also check if user started with "Hey Jarvis..." and strip cleanly
                            val wakeMatch = checkWakeWord(spoken)
                            val cleanSpoken = if (wakeMatch != null && wakeMatch.trailingCommand.isNotBlank()) {
                                wakeMatch.trailingCommand
                            } else {
                                spoken
                            }
                            onSpeechResultCallback?.invoke(cleanSpoken)
                        } else {
                            _assistantState.value = AssistantState.STANDBY
                            if (_isWakeWordActive.value && !isCurrentlySpeaking && !isDestroyed) {
                                scheduleWakeWordRestart(500)
                            }
                        }
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partials = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val partial = partials?.firstOrNull() ?: ""

                    if (isCurrentlyInWakeWordMode) {
                        // Check if wake word detected early in partial speech
                        val wakeMatch = checkWakeWord(partial)
                        if (wakeMatch != null) {
                            playWakeChimeAndVibrate()
                            stopListeningInternal()
                            isCurrentlyInWakeWordMode = false
                            _isWakeWordListening.value = false
                            _assistantState.value = AssistantState.PROCESSING
                            onWakeWordCallback?.invoke(wakeMatch.trailingCommand)
                        }
                    } else {
                        if (partial.isNotBlank()) {
                            _partialSpeechText.value = partial
                        }
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
    }

    private fun checkWakeWord(text: String): WakeWordMatch? {
        val lower = text.lowercase(Locale.ROOT).trim()
        for (phrase in wakeWordPhrases) {
            val index = lower.indexOf(phrase)
            if (index != -1) {
                val trailing = text.substring(index + phrase.length).trim()
                    .removePrefix(",").removePrefix(".").removePrefix("!").removePrefix("?").trim()
                return WakeWordMatch(phrase, trailing)
            }
        }
        return null
    }

    /**
     * Starts continuous listening for "Hey Jarvis" / "Hello Jarvis" wake word.
     */
    fun startWakeWordDetection(onDetected: (trailingCommand: String) -> Unit) {
        this.onWakeWordCallback = onDetected
        _isWakeWordActive.value = true
        preferences.wakeWordEnabled = true
        scheduleWakeWordRestart(100)
    }

    fun stopWakeWordDetection() {
        _isWakeWordActive.value = false
        preferences.wakeWordEnabled = false
        wakeWordRestartJob?.cancel()
        if (isCurrentlyInWakeWordMode) {
            stopListeningInternal()
            isCurrentlyInWakeWordMode = false
            _isWakeWordListening.value = false
        }
    }

    fun toggleWakeWordDetection(onDetected: (trailingCommand: String) -> Unit): Boolean {
        if (_isWakeWordActive.value) {
            stopWakeWordDetection()
            return false
        } else {
            startWakeWordDetection(onDetected)
            return true
        }
    }

    private fun scheduleWakeWordRestart(delayMs: Long) {
        if (!_isWakeWordActive.value || isCurrentlySpeaking || isDestroyed) return
        wakeWordRestartJob?.cancel()
        wakeWordRestartJob = scope.launch {
            delay(delayMs)
            if (_isWakeWordActive.value && !isCurrentlySpeaking && !isDestroyed && _assistantState.value == AssistantState.STANDBY) {
                startWakeWordRecognitionInternal()
            }
        }
    }

    private fun startWakeWordRecognitionInternal() {
        if (isCurrentlySpeaking || isDestroyed) return
        stopListeningInternal()

        isCurrentlyInWakeWordMode = true
        val intent = createSpeechRecognizerIntent(isWakeWord = true)
        try {
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            _isWakeWordListening.value = false
        }
    }

    /**
     * Starts active voice input when user clicks the mic button or after Jarvis wakes up.
     */
    fun startListening(onResult: (String) -> Unit) {
        wakeWordRestartJob?.cancel()
        stopSpeaking()
        stopListeningInternal()

        isCurrentlyInWakeWordMode = false
        _isWakeWordListening.value = false
        this.onSpeechResultCallback = onResult

        val intent = createSpeechRecognizerIntent(isWakeWord = false)
        try {
            _assistantState.value = AssistantState.LISTENING
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            _assistantState.value = AssistantState.STANDBY
            if (_isWakeWordActive.value) {
                scheduleWakeWordRestart(500)
            }
        }
    }

    private fun createSpeechRecognizerIntent(isWakeWord: Boolean): Intent {
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, if (isWakeWord) 1 else 3)
        }
    }

    fun stopListening() {
        stopListeningInternal()
        _assistantState.value = AssistantState.STANDBY
        _audioRms.value = 0f
        if (_isWakeWordActive.value && !isCurrentlySpeaking && !isDestroyed) {
            scheduleWakeWordRestart(500)
        }
    }

    private fun stopListeningInternal() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
        } catch (_: Exception) {}
    }

    /**
     * Cleans raw text to make speech sound natural, smooth, and realistic without reading
     * markdown asterisks, bracket notes, or emoji tags.
     */
    private fun cleanTextForSpeech(raw: String): String {
        return raw
            .replace(Regex("\\*\\*|\\*|_|#|`"), "")
            .replace(Regex("\\[.*?\\]"), "")
            .replace(Regex("https?://\\S+"), "वेबसाइट")
            .replace(Regex("[\\uD83C-\\uDBFF\\uDC00-\\uDFFF]+"), "") // clean emoji sequences
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun speak(text: String, onFinished: (() -> Unit)? = null) {
        val speechText = cleanTextForSpeech(text)
        if (!isTtsReady || speechText.isBlank()) {
            onFinished?.invoke()
            if (_isWakeWordActive.value && !isDestroyed) {
                scheduleWakeWordRestart(500)
            }
            return
        }

        wakeWordRestartJob?.cancel()
        stopListeningInternal()
        isCurrentlyInWakeWordMode = false
        _isWakeWordListening.value = false

        this.onSpeakingCompletedCallback = onFinished

        val tts = textToSpeech ?: return
        tts.setPitch(preferences.voicePitch)
        tts.setSpeechRate(preferences.voiceSpeed)

        val utteranceId = UUID.randomUUID().toString()
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        }

        _assistantState.value = AssistantState.SPEAKING
        tts.speak(speechText, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    fun stopSpeaking() {
        simulatedSpeechPulseJob?.cancel()
        textToSpeech?.stop()
        isCurrentlySpeaking = false
        _audioRms.value = 0f
        if (_assistantState.value == AssistantState.SPEAKING) {
            _assistantState.value = AssistantState.STANDBY
        }
        if (_isWakeWordActive.value && !isDestroyed) {
            scheduleWakeWordRestart(500)
        }
    }

    fun setProcessingState() {
        _assistantState.value = AssistantState.PROCESSING
        _audioRms.value = 0f
    }

    fun setStandbyState() {
        _assistantState.value = AssistantState.STANDBY
        _audioRms.value = 0f
        if (_isWakeWordActive.value && !isCurrentlySpeaking && !isDestroyed) {
            scheduleWakeWordRestart(400)
        }
    }

    fun playWakeChimeAndVibrate() {
        try {
            val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            toneGen.startTone(ToneGenerator.TONE_PROP_BEEP2, 120)
        } catch (_: Throwable) {}

        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(70)
            }
        } catch (_: Throwable) {}
    }

    private fun startSimulatedSpeechAudioWave() {
        simulatedSpeechPulseJob?.cancel()
        simulatedSpeechPulseJob = scope.launch {
            var step = 0
            while (isActive) {
                val wave = (Math.sin(step * 0.4) * 0.35 + Math.sin(step * 0.7) * 0.25 + 0.4).toFloat()
                _audioRms.value = wave.coerceIn(0.1f, 0.95f)
                step++
                delay(60)
            }
        }
    }

    fun destroy() {
        isDestroyed = true
        wakeWordRestartJob?.cancel()
        simulatedSpeechPulseJob?.cancel()
        try {
            speechRecognizer?.destroy()
        } catch (_: Throwable) {}
        try {
            textToSpeech?.stop()
            textToSpeech?.shutdown()
        } catch (_: Throwable) {}
    }
}
