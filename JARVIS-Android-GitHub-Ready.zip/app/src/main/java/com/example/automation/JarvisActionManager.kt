package com.example.automation

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.provider.ContactsContract
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.regex.Pattern

enum class ActionType {
    NONE,
    WAKE_GREETING,
    WHATSAPP_MESSAGE,
    OPEN_APP,
    MAKE_CALL,
    SEND_SMS,
    SEARCH_YOUTUBE,
    SEARCH_GOOGLE,
    OPEN_CAMERA,
    OPEN_MAPS,
    SET_ALARM,
    SET_TIMER,
    TOGGLE_FLASHLIGHT,
    OPEN_SETTINGS,
    MATH_CALCULATION
}

data class ActionResult(
    val handled: Boolean,
    val spokenResponse: String,
    val actionType: ActionType = ActionType.NONE,
    val targetTitle: String = "",
    val actionDetails: String = "",
    val intentToLaunch: Intent? = null
)

class JarvisActionManager(private val context: Context) {

    private var isTorchOn = false

    /**
     * Tries to handle command locally as a direct device action or system control.
     * Returns an ActionResult. If handled == false, fallback to Gemini AI.
     */
    fun processCommand(rawInput: String): ActionResult {
        var query = rawInput.trim()
        val lowerRaw = query.lowercase(Locale.ROOT)

        // Wake word detection & stripping
        val wakePrefixes = listOf(
            "hey jarvis", "hello jarvis", "hi jarvis", "ok jarvis",
            "हे जार्विस", "हेलो जार्विस", "हाय जार्विस", "नमस्ते जार्विस", "सुनो जार्विस", "जार्विस सुनो",
            "hey jarvish", "hello jarvish", "hey javish", "hello javish", "jarvis", "जार्विस"
        )

        var matchedWakePrefix: String? = null
        for (prefix in wakePrefixes) {
            if (lowerRaw.startsWith(prefix)) {
                matchedWakePrefix = prefix
                query = query.substring(prefix.length).trim()
                    .removePrefix(",").removePrefix(".").removePrefix("!").removePrefix("?").trim()
                break
            }
        }

        // If the utterance was ONLY the wake word / greeting, respond warmly in female persona
        if (matchedWakePrefix != null && query.isBlank()) {
            val greetings = listOf(
                "हाँ जी सर! मैं सुन रही हूँ, आज्ञा दीजिए क्या काम है?",
                "नमस्ते सर! मैं जार्विस हूँ। बताइए मैं आपकी क्या सहायता करूँ?",
                "जी सर, मैं पूरी तरह तैयार हूँ! आदेश दें।"
            )
            val randomGreeting = greetings.random()
            return ActionResult(
                handled = true,
                spokenResponse = randomGreeting,
                actionType = ActionType.WAKE_GREETING,
                targetTitle = "जार्विस सक्रिय // WAKE ACTIVE",
                actionDetails = "वेक वर्ड पहचाना गया: '$matchedWakePrefix' - आदेश के लिए तैयार"
            )
        }

        val lower = query.lowercase(Locale.ROOT)

        // 1. WhatsApp Commands
        val whatsappResult = handleWhatsAppCommand(query, lower)
        if (whatsappResult != null) return whatsappResult

        // 2. Flashlight / Torch
        val torchResult = handleFlashlightCommand(lower)
        if (torchResult != null) return torchResult

        // 3. YouTube Search / Play
        val youtubeResult = handleYouTubeCommand(query, lower)
        if (youtubeResult != null) return youtubeResult

        // 4. Google Web Search
        val searchResult = handleSearchCommand(query, lower)
        if (searchResult != null) return searchResult

        // 5. Camera / Photo
        val cameraResult = handleCameraCommand(lower)
        if (cameraResult != null) return cameraResult

        // 6. Navigation / Maps
        val mapsResult = handleMapsCommand(query, lower)
        if (mapsResult != null) return mapsResult

        // 7. Phone / Call / Dialer
        val dialerResult = handleDialerCommand(query, lower)
        if (dialerResult != null) return dialerResult

        // 8. SMS / Messaging
        val smsResult = handleSmsCommand(query, lower)
        if (smsResult != null) return smsResult

        // 9. Alarm / Timer
        val alarmResult = handleAlarmTimerCommand(query, lower)
        if (alarmResult != null) return alarmResult

        // 10. Device Settings (WiFi, Bluetooth, Main Settings)
        val settingsResult = handleSettingsCommand(lower)
        if (settingsResult != null) return settingsResult

        // 11. Quick Math / Calculation
        val mathResult = handleMathCalculation(lower)
        if (mathResult != null) return mathResult

        // 12. App Launching (General "Open [App]" / "[App] kholo")
        val appLaunchResult = handleAppLaunchCommand(query, lower)
        if (appLaunchResult != null) return appLaunchResult

        return ActionResult(handled = false, spokenResponse = "")
    }

    // ==========================================
    // 1. WHATSAPP AUTOMATION
    // ==========================================
    private fun handleWhatsAppCommand(raw: String, lower: String): ActionResult? {
        val isWhatsApp = lower.contains("whatsapp") || lower.contains("वाट्सएप") ||
                lower.contains("व्हाट्सएप") || lower.contains("व्हाट्सऐप") || lower.contains("whatsap")

        if (!isWhatsApp) return null

        // Check if user specifically wants to send a message
        val isMessageIntent = lower.contains("msg") || lower.contains("message") ||
                lower.contains("संदेश") || lower.contains("भेजो") || lower.contains("bhejo") ||
                lower.contains("karo") || lower.contains("bhejna") || lower.contains("send") ||
                lower.contains("bolo") || lower.contains("likho")

        if (isMessageIntent) {
            // Check for explicit phone number
            val phoneRegex = Pattern.compile("(\\+?[0-9]{10,13})")
            val phoneMatcher = phoneRegex.matcher(raw)
            val extractedPhone = if (phoneMatcher.find()) phoneMatcher.group(1) else null

            // Extract message content
            var messageText = extractWhatsAppMessageText(raw)
            if (messageText.isBlank() && !raw.equals("whatsapp", ignoreCase = true)) {
                // If message text extraction didn't find clear delimiter, use text after 'whatsapp'
                messageText = raw.substringAfter("whatsapp", "").trim()
                    .removePrefix("pe").removePrefix("par").removePrefix("me")
                    .removePrefix("message").removePrefix("msg").removePrefix("ko").trim()
            }

            if (extractedPhone != null && extractedPhone.isNotBlank()) {
                val encodedText = try {
                    URLEncoder.encode(messageText.ifBlank { "Hello" }, StandardCharsets.UTF_8.toString())
                } catch (_: Exception) {
                    messageText
                }
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse("https://api.whatsapp.com/send?phone=$extractedPhone&text=$encodedText")
                    setPackage("com.whatsapp")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                return ActionResult(
                    handled = true,
                    spokenResponse = "जी सर! मैं व्हाट्सएप पर $extractedPhone को संदेश भेज रही हूँ।",
                    actionType = ActionType.WHATSAPP_MESSAGE,
                    targetTitle = "WhatsApp Message",
                    actionDetails = "नंबर: $extractedPhone | संदेश: \"$messageText\"",
                    intentToLaunch = intent
                )
            } else {
                // General WhatsApp Send Intent (allows user to select recipient instantly)
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, messageText.ifBlank { "Hello!" })
                    setPackage("com.whatsapp")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                return ActionResult(
                    handled = true,
                    spokenResponse = "जी सर! व्हाट्सएप संदेश तैयार है। कृपया संपर्क चुनें और भेजें।",
                    actionType = ActionType.WHATSAPP_MESSAGE,
                    targetTitle = "WhatsApp Message",
                    actionDetails = "संदेश: \"${messageText.ifBlank { "Hello!" }}\"",
                    intentToLaunch = intent
                )
            }
        }

        // Just open WhatsApp app
        val launchIntent = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
            ?: context.packageManager.getLaunchIntentForPackage("com.whatsapp.w4b")
            ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.whatsapp")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }

        launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        return ActionResult(
            handled = true,
            spokenResponse = "जी सर! व्हाट्सएप खोला जा रहा है।",
            actionType = ActionType.OPEN_APP,
            targetTitle = "WhatsApp",
            actionDetails = "व्हाट्सएप एप्लिकेशन प्रारंभ किया जा रहा है...",
            intentToLaunch = launchIntent
        )
    }

    private fun extractWhatsAppMessageText(input: String): String {
        val delimiters = listOf(
            "bolo ki", "bhejo ki", "likho ki", "message", "msg",
            "bhejo", "karo", "say", "send", "text"
        )
        val lower = input.lowercase(Locale.ROOT)
        for (d in delimiters) {
            val idx = lower.lastIndexOf(d)
            if (idx != -1 && idx + d.length < input.length) {
                val candidate = input.substring(idx + d.length).trim()
                    .removePrefix(":").removePrefix("-").removePrefix("ki").trim()
                if (candidate.isNotBlank() && candidate.length > 1) {
                    return candidate
                }
            }
        }
        return ""
    }

    // ==========================================
    // 2. FLASHLIGHT / TORCH
    // ==========================================
    private fun handleFlashlightCommand(lower: String): ActionResult? {
        val isTorch = lower.contains("torch") || lower.contains("flashlight") ||
                lower.contains("टॉर्च") || lower.contains("फ्लैशलाइट") || lower.contains("फ्लैश")

        if (!isTorch) return null

        val shouldTurnOn = lower.contains("on") || lower.contains("chalu") || lower.contains("jalao") ||
                lower.contains("kholo") || lower.contains("चालू") || lower.contains("जलाओ") || lower.contains("ऑन")

        val shouldTurnOff = lower.contains("off") || lower.contains("band") ||
                lower.contains("bujhao") || lower.contains("बंद") || lower.contains("बुझाओ") || lower.contains("ऑफ")

        val targetState = if (shouldTurnOff) false else if (shouldTurnOn) true else !isTorchOn

        val success = setTorchState(targetState)
        val statusHindi = if (targetState) "चालू कर दी गई है" else "बंद कर दी गई है"
        return ActionResult(
            handled = true,
            spokenResponse = if (success) "जी सर! टॉर्च $statusHindi।" else "माफ़ कीजियेगा सर, टॉर्च नियंत्रित नहीं हो सकी।",
            actionType = ActionType.TOGGLE_FLASHLIGHT,
            targetTitle = "Flashlight / Torch",
            actionDetails = "स्थिति: " + (if (targetState) "ON" else "OFF")
        )
    }

    private fun setTorchState(enable: Boolean): Boolean {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            val cameraId = cameraManager?.cameraIdList?.firstOrNull() ?: return false
            cameraManager.setTorchMode(cameraId, enable)
            isTorchOn = enable
            true
        } catch (_: Throwable) {
            false
        }
    }

    // ==========================================
    // 3. YOUTUBE AUTOMATION
    // ==========================================
    private fun handleYouTubeCommand(raw: String, lower: String): ActionResult? {
        val isYouTube = lower.contains("youtube") || lower.contains("यूट्यूब") || lower.contains("यू ट्यूब")
        if (!isYouTube) return null

        // Check if user specified a song, video, or query to play/search
        val isPlayOrSearch = lower.contains("chalao") || lower.contains("bajao") ||
                lower.contains("play") || lower.contains("search") || lower.contains("dikhhao") ||
                lower.contains("song") || lower.contains("गाना") || lower.contains("सर्च") ||
                lower.contains("बजाओ") || lower.contains("चलाओ")

        var searchQuery = ""
        if (isPlayOrSearch) {
            searchQuery = raw.replace("(?i)youtube".toRegex(), "")
                .replace("(?i)par".toRegex(), "")
                .replace("(?i)pe".toRegex(), "")
                .replace("(?i)chalao".toRegex(), "")
                .replace("(?i)bajao".toRegex(), "")
                .replace("(?i)play".toRegex(), "")
                .replace("(?i)search".toRegex(), "")
                .replace("(?i)karo".toRegex(), "")
                .replace("यूट्यूब", "")
                .replace("पर", "")
                .replace("बजाओ", "")
                .replace("चलाओ", "")
                .trim()
        }

        val intent = if (searchQuery.isNotBlank()) {
            Intent(Intent.ACTION_SEARCH).apply {
                setPackage("com.google.android.youtube")
                putExtra("query", searchQuery)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        } else {
            context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
        }
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK

        val response = if (searchQuery.isNotBlank()) {
            "जी सर! यूट्यूब पर '$searchQuery' चलाया जा रहा है।"
        } else {
            "जी सर! यूट्यूब खोला जा रहा है।"
        }

        return ActionResult(
            handled = true,
            spokenResponse = response,
            actionType = ActionType.SEARCH_YOUTUBE,
            targetTitle = "YouTube",
            actionDetails = if (searchQuery.isNotBlank()) "खोज: $searchQuery" else "यूट्यूब ऐप खोला जा रहा है",
            intentToLaunch = intent
        )
    }

    // ==========================================
    // 4. GOOGLE SEARCH
    // ==========================================
    private fun handleSearchCommand(raw: String, lower: String): ActionResult? {
        val isSearch = lower.startsWith("search ") || lower.contains("google search") ||
                lower.contains("google par search") || lower.contains("सर्च करो") ||
                lower.contains("गूगल पर खोजो") || lower.contains("dhundo")

        if (!isSearch) return null

        val query = raw.replace("(?i)google search".toRegex(), "")
            .replace("(?i)google par search karo".toRegex(), "")
            .replace("(?i)search karo".toRegex(), "")
            .replace("(?i)search".toRegex(), "")
            .replace("(?i)dhundo".toRegex(), "")
            .replace("गूगल", "")
            .replace("सर्च", "")
            .replace("खोजो", "")
            .trim()

        if (query.isBlank()) return null

        val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
            putExtra(SearchManager.QUERY, query)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        return ActionResult(
            handled = true,
            spokenResponse = "जी सर! गूगल पर '$query' खोजा जा रहा है।",
            actionType = ActionType.SEARCH_GOOGLE,
            targetTitle = "Google Search",
            actionDetails = "खोज क्वेरी: \"$query\"",
            intentToLaunch = intent
        )
    }

    // ==========================================
    // 5. CAMERA
    // ==========================================
    private fun handleCameraCommand(lower: String): ActionResult? {
        val isCamera = lower.contains("camera") || lower.contains("कैमरा") ||
                lower.contains("photo khincho") || lower.contains("फोटो खींचो") ||
                lower.contains("selfie") || lower.contains("तस्वीर")

        if (!isCamera) return null

        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        return ActionResult(
            handled = true,
            spokenResponse = "जी सर! कैमरा खोला जा रहा है।",
            actionType = ActionType.OPEN_CAMERA,
            targetTitle = "Camera",
            actionDetails = "कैमरा सेंसर सक्रिय किया जा रहा है...",
            intentToLaunch = intent
        )
    }

    // ==========================================
    // 6. MAPS & NAVIGATION
    // ==========================================
    private fun handleMapsCommand(raw: String, lower: String): ActionResult? {
        val isMaps = lower.contains("maps") || lower.contains("मैप्स") ||
                lower.contains("navigation") || lower.contains("रास्ता") ||
                lower.contains("rasta dikhao") || lower.contains("direction")

        if (!isMaps) return null

        val destination = raw.replace("(?i)maps".toRegex(), "")
            .replace("(?i)rasta dikhao".toRegex(), "")
            .replace("(?i)direction".toRegex(), "")
            .replace("(?i)navigation".toRegex(), "")
            .replace("मैप्स", "")
            .replace("रास्ता दिखाओ", "")
            .replace("का रास्ता", "")
            .trim()

        val geoUri = if (destination.isNotBlank()) {
            Uri.parse("geo:0,0?q=${Uri.encode(destination)}")
        } else {
            Uri.parse("geo:0,0?q=")
        }

        val intent = Intent(Intent.ACTION_VIEW, geoUri).apply {
            setPackage("com.google.android.apps.maps")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        val spoken = if (destination.isNotBlank()) {
            "जी सर! $destination का रास्ता गूगल मैप्स पर खोला जा रहा है।"
        } else {
            "जी सर! गूगल मैप्स नेविगेशन खोला जा रहा है।"
        }

        return ActionResult(
            handled = true,
            spokenResponse = spoken,
            actionType = ActionType.OPEN_MAPS,
            targetTitle = "Google Maps",
            actionDetails = if (destination.isNotBlank()) "गंतव्य: $destination" else "नेविगेशन मैप्स सक्रिय",
            intentToLaunch = intent
        )
    }

    // ==========================================
    // 7. PHONE CALL / DIALER
    // ==========================================
    private fun handleDialerCommand(raw: String, lower: String): ActionResult? {
        // Supports:
        // "call Tinku Chacha"
        // "call to mom"
        // "Tinku Chacha ko call karo"
        // "Tinku Chacha ko phone lagao"
        // and direct phone numbers.
        val callWords = listOf(
            "call", "phone", "dial",
            "call karo", "phone karo", "call kar", "phone kar",
            "call lagao", "phone lagao",
            "call kro", "phone kro",
            "कॉल", "फोन", "डायल"
        )
        val isCall = callWords.any { lower.contains(it) }
        if (!isCall) return null

        val phoneRegex = Pattern.compile("(\\+?[0-9][0-9\\s\\-]{8,14}[0-9])")
        val matcher = phoneRegex.matcher(raw)
        val number = if (matcher.find()) matcher.group(1).replace(Regex("[\\s\\-]"), "") else ""

        if (number.isNotBlank()) {
            if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED) {
                return ActionResult(
                    handled = true,
                    spokenResponse = "Boss, phone call permission is required. Please allow it and try again.",
                    actionType = ActionType.MAKE_CALL,
                    targetTitle = "Phone Call",
                    actionDetails = "CALL_PHONE permission required"
                )
            }

            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            return ActionResult(
                handled = true,
                spokenResponse = "Calling $number now, Boss.",
                actionType = ActionType.MAKE_CALL,
                targetTitle = "Phone Call",
                actionDetails = "Number: $number",
                intentToLaunch = intent
            )
        }

        // Extract a contact name from natural-language call commands.
        val contactName = extractContactNameForCall(raw)
        if (contactName.isBlank()) {
            return ActionResult(
                handled = true,
                spokenResponse = "Boss, please tell me the contact name or phone number.",
                actionType = ActionType.MAKE_CALL,
                targetTitle = "Phone Call",
                actionDetails = "No contact name or phone number detected"
            )
        }

        if (ContextCompat.checkSelfPermission(context, android.Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED) {
            return ActionResult(
                handled = true,
                spokenResponse = "Boss, contacts and phone permissions are required. Please allow them and try again.",
                actionType = ActionType.MAKE_CALL,
                targetTitle = "Phone Call",
                actionDetails = "READ_CONTACTS/CALL_PHONE permission required"
            )
        }

        val contacts = findContactNumbers(contactName)

        if (contacts.isEmpty()) {
            return ActionResult(
                handled = true,
                spokenResponse = "Boss, I couldn't find $contactName in your contacts.",
                actionType = ActionType.MAKE_CALL,
                targetTitle = "Contact Not Found",
                actionDetails = "No contact matched: $contactName"
            )
        }

        // If several different contacts match, don't guess which person to call.
        val distinct = contacts.distinctBy { "${it.first.lowercase(Locale.ROOT)}|${it.second}" }
        if (distinct.size > 1) {
            val names = distinct.take(3).joinToString(", ") { it.first }
            return ActionResult(
                handled = true,
                spokenResponse = "Boss, I found multiple contacts: $names. Please say the exact name.",
                actionType = ActionType.MAKE_CALL,
                targetTitle = "Multiple Contacts",
                actionDetails = "Matches: $names"
            )
        }

        val matchedName = distinct.first().first
        val matchedNumber = distinct.first().second
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$matchedNumber")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        return ActionResult(
            handled = true,
            spokenResponse = "Calling $matchedName now, Boss.",
            actionType = ActionType.MAKE_CALL,
            targetTitle = matchedName,
            actionDetails = "Number: $matchedNumber",
            intentToLaunch = intent
        )
    }

    private fun extractContactNameForCall(raw: String): String {
        var value = raw.trim()

        // Remove common command phrases from the beginning/end.
        val patterns = listOf(
            "(?i)^please\\s+",
            "(?i)^call\\s+to\\s+",
            "(?i)^call\\s+",
            "(?i)^phone\\s+to\\s+",
            "(?i)^phone\\s+",
            "(?i)^dial\\s+",
            "(?i)^to\\s+",
            "(?i)\\s+ko\\s+call\\s+karo$",
            "(?i)\\s+ko\\s+phone\\s+karo$",
            "(?i)\\s+ko\\s+call\\s+kar$",
            "(?i)\\s+ko\\s+phone\\s+kar$",
            "(?i)\\s+ko\\s+call\\s+lagao$",
            "(?i)\\s+ko\\s+phone\\s+lagao$",
            "(?i)\\s+ko\\s+call\\s+kro$",
            "(?i)\\s+ko\\s+phone\\s+kro$",
            "(?i)\\s+call\\s+karo$",
            "(?i)\\s+phone\\s+karo$",
            "(?i)\\s+call\\s+kar$",
            "(?i)\\s+phone\\s+kar$",
            "(?i)\\s+call\\s+lagao$",
            "(?i)\\s+phone\\s+lagao$"
        )
        for (pattern in patterns) {
            value = value.replace(pattern.toRegex(), "").trim()
        }

        // English "call to mom" can leave a leading "to".
        value = value.replace("(?i)^to\\s+".toRegex(), "").trim()
        return value.trim(' ', ',', '.', '!', '?')
    }

    private fun findContactNumbers(contactName: String): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        val resolver = context.contentResolver

        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )

        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val args = arrayOf("%$contactName%")

        try {
            resolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                selection,
                args,
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} COLLATE NOCASE ASC"
            )?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
                )
                val numberIndex = cursor.getColumnIndex(
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                )

                while (cursor.moveToNext()) {
                    if (nameIndex >= 0 && numberIndex >= 0) {
                        val name = cursor.getString(nameIndex)?.trim().orEmpty()
                        val phone = cursor.getString(numberIndex)?.trim().orEmpty()
                        if (name.isNotBlank() && phone.isNotBlank()) {
                            result.add(name to phone)
                        }
                    }
                }
            }
        } catch (_: SecurityException) {
            return emptyList()
        } catch (_: Throwable) {
            return emptyList()
        }

        // Prefer an exact case-insensitive name match over a partial match.
        val exact = result.filter { it.first.equals(contactName.trim(), ignoreCase = true) }
        return if (exact.isNotEmpty()) exact else result
    }

    // ==========================================
    // 8. SMS / MESSAGING
    // ==========================================
    private fun handleSmsCommand(raw: String, lower: String): ActionResult? {
        val isSms = (lower.contains("sms") || lower.contains("एसएमएस") || lower.contains("message bhejo")) &&
                !lower.contains("whatsapp")

        if (!isSms) return null

        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:")
            putExtra("sms_body", raw.replace("(?i)sms".toRegex(), "").trim())
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        return ActionResult(
            handled = true,
            spokenResponse = "जी सर! एसएमएस संदेश तैयार किया जा रहा है।",
            actionType = ActionType.SEND_SMS,
            targetTitle = "SMS Messages",
            actionDetails = "संदेश ऐप खोला जा रहा है...",
            intentToLaunch = intent
        )
    }

    // ==========================================
    // 9. ALARM & TIMER
    // ==========================================
    private fun handleAlarmTimerCommand(raw: String, lower: String): ActionResult? {
        if (lower.contains("alarm") || lower.contains("अलार्म")) {
            // Try to find hour
            val hourRegex = Pattern.compile("(\\d{1,2})\\s*(?:baje|am|pm|baje ka)?")
            val matcher = hourRegex.matcher(lower)
            var hour = 7
            if (matcher.find()) {
                val parsed = matcher.group(1)?.toIntOrNull()
                if (parsed != null && parsed in 1..23) hour = parsed
            }

            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, 0)
                putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS Alarm")
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }

            return ActionResult(
                handled = true,
                spokenResponse = "जी सर! $hour बजे का अलार्म सेट किया जा रहा है।",
                actionType = ActionType.SET_ALARM,
                targetTitle = "Alarm Clock",
                actionDetails = "समय: $hour:00",
                intentToLaunch = intent
            )
        }

        if (lower.contains("timer") || lower.contains("टाइमर")) {
            val minRegex = Pattern.compile("(\\d{1,3})\\s*(?:minute|min|sec|second)?")
            val matcher = minRegex.matcher(lower)
            var seconds = 300 // default 5 mins
            if (matcher.find()) {
                val parsed = matcher.group(1)?.toIntOrNull()
                if (parsed != null) seconds = parsed * 60
            }

            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS Timer")
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }

            return ActionResult(
                handled = true,
                spokenResponse = "जी सर! ${seconds / 60} मिनट का टाइमर लगाया जा रहा है।",
                actionType = ActionType.SET_TIMER,
                targetTitle = "Timer",
                actionDetails = "अवधि: ${seconds / 60} मिनट",
                intentToLaunch = intent
            )
        }

        return null
    }

    // ==========================================
    // 10. SYSTEM SETTINGS
    // ==========================================
    private fun handleSettingsCommand(lower: String): ActionResult? {
        if (lower.contains("wifi") || lower.contains("वाईफाई")) {
            return ActionResult(
                handled = true,
                spokenResponse = "जी सर! वाई-फाई सेटिंग्स खोली जा रही हैं।",
                actionType = ActionType.OPEN_SETTINGS,
                targetTitle = "Wi-Fi Settings",
                actionDetails = "नेटवर्क कॉन्फ़िगरेशन",
                intentToLaunch = Intent(Settings.ACTION_WIFI_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            )
        }

        if (lower.contains("bluetooth") || lower.contains("ब्लूटूथ")) {
            return ActionResult(
                handled = true,
                spokenResponse = "जी सर! ब्लूटूथ सेटिंग्स खोली जा रही हैं।",
                actionType = ActionType.OPEN_SETTINGS,
                targetTitle = "Bluetooth Settings",
                actionDetails = "वायरलेस डिवाइस कनेक्टिविटी",
                intentToLaunch = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            )
        }

        if (lower.contains("settings") || lower.contains("सेटिंग्स") || lower.contains("सेटिंग")) {
            return ActionResult(
                handled = true,
                spokenResponse = "जी सर! डिवाइस सेटिंग्स खोली जा रही हैं।",
                actionType = ActionType.OPEN_SETTINGS,
                targetTitle = "System Settings",
                actionDetails = "एंड्रॉइड मुख्य सेटिंग्स",
                intentToLaunch = Intent(Settings.ACTION_SETTINGS).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
            )
        }

        return null
    }

    // ==========================================
    // 11. QUICK MATH / CALCULATION
    // ==========================================
    private fun handleMathCalculation(lower: String): ActionResult? {
        val mathPattern = Pattern.compile("([0-9]+(?:\\.[0-9]+)?)\\s*(\\+|\\-|\\*|\\/|x|guna|plus|minus|into|divide|का|percentage|percent)\\s*([0-9]+(?:\\.[0-9]+)?)")
        val matcher = mathPattern.matcher(lower)
        if (matcher.find()) {
            val num1 = matcher.group(1)?.toDoubleOrNull() ?: return null
            val op = matcher.group(2) ?: ""
            val num2 = matcher.group(3)?.toDoubleOrNull() ?: return null

            val result = when {
                op == "+" || op == "plus" -> num1 + num2
                op == "-" || op == "minus" -> num1 - num2
                op == "*" || op == "x" || op == "guna" || op == "into" -> num1 * num2
                op == "/" || op == "divide" -> if (num2 != 0.0) num1 / num2 else Double.NaN
                op.contains("percent") || op == "का" -> (num1 * num2) / 100.0
                else -> return null
            }

            val formatted = if (result % 1.0 == 0.0) result.toLong().toString() else "%.2f".format(result)
            return ActionResult(
                handled = true,
                spokenResponse = "सर, इसका परिणाम $formatted है।",
                actionType = ActionType.MATH_CALCULATION,
                targetTitle = "Calculator HUD",
                actionDetails = "$num1 $op $num2 = $formatted"
            )
        }
        return null
    }

    // ==========================================
    // 12. GENERAL APP LAUNCHER (A TO Z)
    // ==========================================
    private fun handleAppLaunchCommand(raw: String, lower: String): ActionResult? {
        val isOpen = lower.startsWith("open ") || lower.startsWith("launch ") ||
                lower.endsWith(" kholo") || lower.endsWith(" open karo") ||
                lower.endsWith(" chalu karo") || lower.contains("खोलो") ||
                lower.contains("ओपन करो") || lower.contains("चालू करो")

        if (!isOpen) return null

        val appNameClean = lower.replace("open ", "")
            .replace("launch ", "")
            .replace(" kholo", "")
            .replace(" open karo", "")
            .replace(" chalu karo", "")
            .replace("खोलो", "")
            .replace("ओपन करो", "")
            .replace("चालू करो", "")
            .trim()

        if (appNameClean.isBlank()) return null

        // Well-known app map
        val knownPackages = mapOf(
            "chrome" to "com.android.chrome",
            "browser" to "com.android.chrome",
            "क्रोम" to "com.android.chrome",
            "instagram" to "com.instagram.android",
            "insta" to "com.instagram.android",
            "इंस्टाग्राम" to "com.instagram.android",
            "telegram" to "org.telegram.messenger",
            "टेलीग्राम" to "org.telegram.messenger",
            "spotify" to "com.spotify.music",
            "स्पॉटिफ़ाई" to "com.spotify.music",
            "play store" to "com.android.vending",
            "प्ले स्टोर" to "com.android.vending",
            "calculator" to "com.google.android.calculator",
            "कैलकुलेटर" to "com.google.android.calculator",
            "gmail" to "com.google.android.gm",
            "जीमेल" to "com.google.android.gm",
            "photos" to "com.google.android.apps.photos",
            "gallery" to "com.google.android.apps.photos",
            "गैलरी" to "com.google.android.apps.photos"
        )

        val targetPackage = knownPackages[appNameClean]

        if (targetPackage != null) {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(targetPackage)
            if (launchIntent != null) {
                launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                return ActionResult(
                    handled = true,
                    spokenResponse = "जी सर! $appNameClean ऐप खोला जा रहा है।",
                    actionType = ActionType.OPEN_APP,
                    targetTitle = appNameClean.uppercase(Locale.ROOT),
                    actionDetails = "पैकेज: $targetPackage प्रारंभ किया गया",
                    intentToLaunch = launchIntent
                )
            }
        }

        // Search installed apps dynamically on the device!
        try {
            val pm = context.packageManager
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val pkgAppsList = pm.queryIntentActivities(mainIntent, 0)
            for (resolveInfo in pkgAppsList) {
                val appLabel = resolveInfo.loadLabel(pm).toString().lowercase(Locale.ROOT)
                if (appLabel.contains(appNameClean) || appNameClean.contains(appLabel)) {
                    val pkg = resolveInfo.activityInfo.packageName
                    val launchIntent = pm.getLaunchIntentForPackage(pkg)
                    if (launchIntent != null) {
                        launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        return ActionResult(
                            handled = true,
                            spokenResponse = "जी सर! ${resolveInfo.loadLabel(pm)} खोला जा रहा है।",
                            actionType = ActionType.OPEN_APP,
                            targetTitle = resolveInfo.loadLabel(pm).toString(),
                            actionDetails = "सक्रिय एप्लिकेशन: $pkg",
                            intentToLaunch = launchIntent
                        )
                    }
                }
            }
        } catch (_: Throwable) {}

        // Fallback: Open Play Store for this app
        val playStoreIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=${Uri.encode(appNameClean)}")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        return ActionResult(
            handled = true,
            spokenResponse = "सर, आपके डिवाइस में $appNameClean स्थापित नहीं है। मैं इसे प्ले स्टोर पर खोल रही हूँ।",
            actionType = ActionType.OPEN_APP,
            targetTitle = "$appNameClean (Play Store)",
            actionDetails = "प्ले स्टोर पर खोजा जा रहा है...",
            intentToLaunch = playStoreIntent
        )
    }
}
