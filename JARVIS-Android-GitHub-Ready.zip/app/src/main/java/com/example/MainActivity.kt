package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import com.example.ui.JarvisMainScreen
import com.example.ui.theme.JarvisBackground
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.JarvisViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: JarvisViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = JarvisBackground
                ) {
                    JarvisApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun JarvisApp(viewModel: JarvisViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var hasRecordAudioPermission by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasRecordAudioPermission = isGranted
        if (!isGranted) {
            // Inform user why audio permission is needed
            Toast.makeText(
                context,
                "जार्विस के साथ बातचीत करने के लिए ऑडियो रिकॉर्डिंग अनुमति आवश्यक है।",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    val devicePermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        // Device-control permissions are optional until a corresponding command is used.
        // The call/contact action manager reports a precise permission message if denied.
    }

    LaunchedEffect(Unit) {
        val currentCheck = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        hasRecordAudioPermission = currentCheck
        if (!currentCheck) {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        val missingDevicePermissions = listOf(
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        ).filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missingDevicePermissions.isNotEmpty()) {
            devicePermissionsLauncher.launch(missingDevicePermissions.toTypedArray())
        }
    }

    JarvisMainScreen(
        viewModel = viewModel,
        onRequireAudioPermission = {
            if (!hasRecordAudioPermission) {
                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    )
}
