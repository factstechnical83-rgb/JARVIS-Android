package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.automation.ActionResult
import com.example.automation.ActionType
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisCyanBright
import com.example.ui.theme.JarvisElectricBlue
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGreen
import com.example.ui.theme.JarvisRed
import com.example.ui.theme.JarvisSurfaceBorder
import com.example.ui.theme.JarvisSurfaceCard
import com.example.ui.theme.JarvisSurfaceDark
import com.example.ui.theme.JarvisTextMuted
import com.example.ui.theme.JarvisTextPrimary

@Composable
fun ActionExecutionCard(
    action: ActionResult,
    onTriggerAgain: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "action_card_pulse")
    val dotPulse by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "action_dot"
    )

    val actionColor = when (action.actionType) {
        ActionType.WHATSAPP_MESSAGE -> JarvisGreen
        ActionType.SEARCH_YOUTUBE -> JarvisRed
        ActionType.OPEN_CAMERA -> JarvisCyanBright
        ActionType.OPEN_MAPS -> JarvisElectricBlue
        ActionType.MAKE_CALL -> JarvisGreen
        ActionType.TOGGLE_FLASHLIGHT -> JarvisGold
        ActionType.SET_ALARM, ActionType.SET_TIMER -> JarvisGold
        ActionType.MATH_CALCULATION -> JarvisCyan
        else -> JarvisCyan
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .border(1.5.dp, actionColor.copy(alpha = 0.65f), RoundedCornerShape(12.dp))
            .background(JarvisSurfaceDark.copy(alpha = 0.95f), RoundedCornerShape(12.dp))
            .padding(12.dp)
            .testTag("action_execution_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .clip(CircleShape)
                            .background(actionColor.copy(alpha = dotPulse))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "कमांड निष्पादित // ${action.targetTitle.ifBlank { "SYSTEM ACTION" }}",
                        color = actionColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                if (action.actionDetails.isNotBlank()) {
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = action.actionDetails,
                        color = JarvisTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            if (action.intentToLaunch != null) {
                Button(
                    onClick = onTriggerAgain,
                    colors = ButtonDefaults.buttonColors(containerColor = actionColor.copy(alpha = 0.25f)),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, actionColor),
                    modifier = Modifier.height(32.dp).testTag("action_retrigger_btn")
                ) {
                    Text(
                        text = "ओपन करें",
                        color = actionColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun QuickActionDeck(
    onCommandSelect: (String) -> Unit,
    onSendWhatsApp: (msg: String, phone: String) -> Unit,
    modifier: Modifier = Modifier
) {
    var showWhatsAppQuickBox by remember { mutableStateOf(false) }
    var quickMsgText by remember { mutableStateOf("") }
    var quickPhoneText by remember { mutableStateOf("") }
    val keyboardController = LocalSoftwareKeyboardController.current

    val submitWhatsApp = {
        if (quickMsgText.isNotBlank() || quickPhoneText.isNotBlank()) {
            keyboardController?.hide()
            onSendWhatsApp(quickMsgText, quickPhoneText)
            quickMsgText = ""
            showWhatsAppQuickBox = false
        }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        // App Launcher Shortcuts Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "A-TO-Z ऑटोमेशन कमांड्स (DIRECT LAUNCH):",
                color = JarvisTextMuted,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 0.6.sp
            )

            Text(
                text = if (showWhatsAppQuickBox) "✕ बंद करें" else "+ व्हाट्सऐप संदेश",
                color = JarvisGreen,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clickable { showWhatsAppQuickBox = !showWhatsAppQuickBox }
                    .padding(4.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // WhatsApp Quick Compose Drawer
        AnimatedVisibility(
            visible = showWhatsAppQuickBox,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, JarvisGreen.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    .background(JarvisSurfaceCard, RoundedCornerShape(10.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "व्हाट्सएप डायरेक्ट सेंडर (WHATSAPP DISPATCH)",
                    color = JarvisGreen,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = quickPhoneText,
                    onValueChange = { quickPhoneText = it },
                    placeholder = { Text("फोन नंबर (वैकल्पिक, उदा: 9876543210)", color = JarvisTextMuted, fontSize = 11.sp) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Next),
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = JarvisGreen,
                        unfocusedBorderColor = JarvisSurfaceBorder,
                        focusedTextColor = JarvisTextPrimary,
                        unfocusedTextColor = JarvisTextPrimary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = quickMsgText,
                        onValueChange = { quickMsgText = it },
                        placeholder = { Text("संदेश लिखें...", color = JarvisTextMuted, fontSize = 11.sp) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { submitWhatsApp() }),
                        modifier = Modifier.weight(1f).height(48.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = JarvisGreen,
                            unfocusedBorderColor = JarvisSurfaceBorder,
                            focusedTextColor = JarvisTextPrimary,
                            unfocusedTextColor = JarvisTextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { submitWhatsApp() },
                        colors = ButtonDefaults.buttonColors(containerColor = JarvisGreen),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = Color.Black,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Direct App Grid Bar (Horizontal)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AppShortcutChip(
                icon = Icons.AutoMirrored.Filled.Chat,
                label = "व्हाट्सएप",
                color = JarvisGreen,
                onClick = { onCommandSelect("whatsapp kholo") }
            )
            AppShortcutChip(
                icon = Icons.Default.PlayArrow,
                label = "यूट्यूब",
                color = JarvisRed,
                onClick = { onCommandSelect("youtube kholo") }
            )
            AppShortcutChip(
                icon = Icons.Default.CameraAlt,
                label = "कैमरा",
                color = JarvisCyanBright,
                onClick = { onCommandSelect("camera kholo") }
            )
            AppShortcutChip(
                icon = Icons.Default.FlashlightOn,
                label = "टॉर्च",
                color = JarvisGold,
                onClick = { onCommandSelect("torch chalu karo") }
            )
            AppShortcutChip(
                icon = Icons.Default.Map,
                label = "मैप्स",
                color = JarvisElectricBlue,
                onClick = { onCommandSelect("maps kholo") }
            )
            AppShortcutChip(
                icon = Icons.Default.Language,
                label = "क्रोम",
                color = JarvisCyan,
                onClick = { onCommandSelect("chrome kholo") }
            )
            AppShortcutChip(
                icon = Icons.Default.Call,
                label = "फोन कॉल",
                color = JarvisGreen,
                onClick = { onCommandSelect("dialer kholo") }
            )
            AppShortcutChip(
                icon = Icons.Default.Settings,
                label = "सेटिंग्स",
                color = JarvisTextMuted,
                onClick = { onCommandSelect("settings kholo") }
            )
        }
    }
}

@Composable
private fun AppShortcutChip(
    icon: ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .border(1.2.dp, color.copy(alpha = 0.55f), RoundedCornerShape(16.dp))
            .background(
                androidx.compose.ui.graphics.Brush.horizontalGradient(
                    listOf(JarvisSurfaceDark, color.copy(alpha = 0.12f))
                ),
                RoundedCornerShape(16.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 11.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = color,
            modifier = Modifier.size(15.dp)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = label,
            color = color,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
