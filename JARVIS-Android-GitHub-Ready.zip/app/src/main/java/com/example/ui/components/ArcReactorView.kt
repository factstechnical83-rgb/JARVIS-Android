package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.audio.AssistantState
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisCyanBright
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGreen
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ArcReactorView(
    assistantState: AssistantState,
    audioRms: Float,
    modifier: Modifier = Modifier,
    size: Dp = 260.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "reactor_transition")

    // Continuous slow rotation for outer ring
    val outerAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outer_rotation"
    )

    // Counter-rotation for inner telemetry ring
    val innerAngle by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                if (assistantState == AssistantState.PROCESSING) 2000 else 8000,
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "inner_rotation"
    )

    // Orbital particles angle
    val particleAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "particle_angle"
    )

    // Breathing pulse for idle state
    val idlePulse by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "idle_pulse"
    )

    // Smooth transition for audio reactive scale
    val animatedRms by animateFloatAsState(
        targetValue = if (assistantState == AssistantState.LISTENING || assistantState == AssistantState.SPEAKING) {
            audioRms
        } else {
            0.1f
        },
        animationSpec = tween(durationMillis = 80),
        label = "animated_rms"
    )

    val coreColor = when (assistantState) {
        AssistantState.STANDBY -> JarvisCyan
        AssistantState.LISTENING -> JarvisGreen
        AssistantState.PROCESSING -> JarvisGold
        AssistantState.SPEAKING -> JarvisCyanBright
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val maxRadius = (this.size.minDimension / 2f) * 0.95f

            // 1. Draw outermost faint HUD ring
            drawCircle(
                color = JarvisCyan.copy(alpha = 0.15f),
                radius = maxRadius,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )

            // 2. Outer segmented rotating ring with cyber ticks
            rotate(degrees = outerAngle, pivot = center) {
                drawOuterSegmentedRing(center, maxRadius * 0.90f, coreColor)
            }

            // 3. Counter-rotating inner ring with glowing data sectors
            rotate(degrees = innerAngle, pivot = center) {
                drawInnerSectorsRing(center, maxRadius * 0.72f, coreColor, assistantState)
            }

            // 4. Audio reactive waveform / ripple ring
            val reactiveRadius = maxRadius * (0.45f + (animatedRms * 0.25f))
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        coreColor.copy(alpha = 0.35f + (animatedRms * 0.4f)),
                        coreColor.copy(alpha = 0.05f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = reactiveRadius * 1.5f
                ),
                radius = reactiveRadius * 1.5f,
                center = center
            )

            // 5. Soundwave frequency rays (36 radiating spokes)
            drawSoundWaveSpokes(
                center = center,
                innerRadius = maxRadius * 0.48f,
                maxRadius = maxRadius * 0.68f,
                rms = animatedRms,
                state = assistantState,
                color = coreColor
            )

            // 6. Glowing Arc Reactor Core Center
            val pulseScale = if (assistantState == AssistantState.STANDBY) idlePulse else (1f + animatedRms * 0.35f)
            val coreRadius = maxRadius * 0.32f * pulseScale

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.95f),
                        coreColor,
                        coreColor.copy(alpha = 0.6f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = coreRadius
                ),
                radius = coreRadius,
                center = center
            )

            // 7. Center triangle / geometric reactor emblem
            drawCenterEmblem(center, coreRadius * 0.65f, coreColor)

            // 8. Dynamic orbiting data nodes / energy sparks
            drawOrbitingEnergySparks(
                center = center,
                orbitRadius = maxRadius * 0.82f,
                baseAngle = particleAngle,
                color = coreColor,
                count = 6
            )
        }
    }
}

private fun DrawScope.drawOuterSegmentedRing(
    center: Offset,
    radius: Float,
    color: Color
) {
    val strokeWidth = 2.dp.toPx()
    val segments = 8
    val sweepAngle = 28f
    val gapAngle = (360f - (segments * sweepAngle)) / segments

    for (i in 0 until segments) {
        val startAngle = i * (sweepAngle + gapAngle)
        drawArc(
            color = color.copy(alpha = 0.6f),
            startAngle = startAngle,
            sweepAngle = sweepAngle,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2),
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )

        // Add cyber dot marker
        val markerRad = Math.toRadians((startAngle + sweepAngle / 2.0)).toFloat()
        val dotX = center.x + (radius + 6.dp.toPx()) * cos(markerRad)
        val dotY = center.y + (radius + 6.dp.toPx()) * sin(markerRad)
        drawCircle(
            color = color.copy(alpha = 0.8f),
            radius = 2.dp.toPx(),
            center = Offset(dotX, dotY)
        )
    }
}

private fun DrawScope.drawInnerSectorsRing(
    center: Offset,
    radius: Float,
    color: Color,
    state: AssistantState
) {
    val strokeWidth = 3.dp.toPx()
    val sectors = 4
    val sweep = 65f
    val gap = (360f - (sectors * sweep)) / sectors

    for (i in 0 until sectors) {
        val startAngle = i * (sweep + gap)
        val alpha = if (state == AssistantState.PROCESSING) {
            if (i % 2 == 0) 0.9f else 0.4f
        } else {
            0.65f
        }

        drawArc(
            color = color.copy(alpha = alpha),
            startAngle = startAngle,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2),
            style = Stroke(width = strokeWidth)
        )
    }
}

private fun DrawScope.drawSoundWaveSpokes(
    center: Offset,
    innerRadius: Float,
    maxRadius: Float,
    rms: Float,
    state: AssistantState,
    color: Color
) {
    val count = 28
    val angleStep = (2 * PI / count).toFloat()

    for (i in 0 until count) {
        val angle = i * angleStep
        // Modulate length with RMS
        val variation = sin((i * 0.8f) + (rms * 10f)).coerceIn(-1f, 1f)
        val dynamicLength = when (state) {
            AssistantState.LISTENING, AssistantState.SPEAKING -> {
                (maxRadius - innerRadius) * (0.3f + rms * 0.7f * (0.6f + 0.4f * variation))
            }
            AssistantState.PROCESSING -> {
                (maxRadius - innerRadius) * (0.5f + 0.4f * sin(i + rms * 5f))
            }
            AssistantState.STANDBY -> {
                (maxRadius - innerRadius) * 0.2f
            }
        }

        val outerR = innerRadius + dynamicLength
        val startX = center.x + innerRadius * cos(angle)
        val startY = center.y + innerRadius * sin(angle)
        val endX = center.x + outerR * cos(angle)
        val endY = center.y + outerR * sin(angle)

        drawLine(
            color = color.copy(alpha = 0.5f + rms * 0.5f),
            start = Offset(startX, startY),
            end = Offset(endX, endY),
            strokeWidth = 2.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

private fun DrawScope.drawCenterEmblem(
    center: Offset,
    size: Float,
    color: Color
) {
    // Inverted sci-fi triangle / arc core
    val path = Path().apply {
        val r = size * 0.8f
        moveTo(center.x, center.y + r)
        lineTo(center.x - r * 0.866f, center.y - r * 0.5f)
        lineTo(center.x + r * 0.866f, center.y - r * 0.5f)
        close()
    }

    drawPath(
        path = path,
        color = Color(0xFF070B14),
        style = androidx.compose.ui.graphics.drawscope.Fill
    )

    drawPath(
        path = path,
        color = color,
        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
    )

    // Inner bright center spark
    drawCircle(
        color = Color.White,
        radius = 3.dp.toPx(),
        center = center
    )
}

private fun DrawScope.drawOrbitingEnergySparks(
    center: Offset,
    orbitRadius: Float,
    baseAngle: Float,
    color: Color,
    count: Int
) {
    val angleStep = 360f / count
    for (i in 0 until count) {
        val angleDeg = baseAngle + (i * angleStep)
        val rad = Math.toRadians(angleDeg.toDouble()).toFloat()
        val px = center.x + orbitRadius * cos(rad)
        val py = center.y + orbitRadius * sin(rad)

        // Trailing glow
        drawCircle(
            color = color.copy(alpha = 0.25f),
            radius = 5.dp.toPx(),
            center = Offset(px, py)
        )
        // Core spark
        drawCircle(
            color = Color.White,
            radius = 2.dp.toPx(),
            center = Offset(px, py)
        )
    }
}

