package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AssistantState
import com.example.automation.ActionResult
import com.example.ui.components.ActionExecutionCard
import com.example.ui.components.ArcReactorView
import com.example.ui.components.CyberHudBackground
import com.example.ui.components.ConversationHistoryDialog
import com.example.ui.components.QuickActionDeck
import com.example.ui.components.SettingsDialog
import com.example.ui.theme.JarvisBackground
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisCyanBright
import com.example.ui.theme.JarvisElectricBlue
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGreen
import com.example.ui.theme.JarvisRed
import com.example.ui.theme.JarvisSurfaceBorder
import com.example.ui.theme.JarvisSurfaceCard
import com.example.ui.theme.JarvisSurfaceDark
import com.example.ui.theme.JarvisTextMuted
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary
import com.example.viewmodel.JarvisViewModel

@Composable
fun JarvisMainScreen(
    viewModel: JarvisViewModel,
    onRequireAudioPermission: () -> Unit
) {
    val assistantState by viewModel.assistantState.collectAsState()
    val audioRms by viewModel.audioRms.collectAsState()
    val partialSpeech by viewModel.partialSpeechText.collectAsState()
    val latestUserPrompt by viewModel.latestUserPrompt.collectAsState()
    val latestJarvisResponse by viewModel.latestJarvisResponse.collectAsState()
    val lastExecutedAction by viewModel.lastExecutedAction.collectAsState()
    val chatHistory by viewModel.chatHistory.collectAsState()
    val isSettingsOpen by viewModel.isSettingsOpen.collectAsState()
    val isHistoryOpen by viewModel.isConversationHistoryOpen.collectAsState()
    val hasApiKey by viewModel.hasApiKey.collectAsState()
    val isWakeWordActive by viewModel.isWakeWordActive.collectAsState()
    val isWakeWordListening by viewModel.isWakeWordListening.collectAsState()

    var showTextInput by remember { mutableStateOf(false) }
    var typedQuery by remember { mutableStateOf("") }

    val infinitePulse = rememberInfiniteTransition(label = "pulse_trans")
    val buttonGlowPulse by infinitePulse.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "btn_glow"
    )

    val micButtonColor by animateColorAsState(
        targetValue = when (assistantState) {
            AssistantState.STANDBY -> JarvisCyan
            AssistantState.LISTENING -> JarvisGreen
            AssistantState.PROCESSING -> JarvisGold
            AssistantState.SPEAKING -> JarvisCyanBright
        },
        label = "mic_color"
    )

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("jarvis_main_scaffold"),
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = JarvisBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Sci-Fi Holographic HUD Animated Grid & Laser Scanline
            CyberHudBackground(
                assistantState = assistantState,
                audioRms = audioRms
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .imePadding()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
            // TOP HUD HEADER
            TopHudHeader(
                assistantState = assistantState,
                hasApiKey = hasApiKey,
                chatCount = chatHistory.size,
                onOpenHistory = { viewModel.toggleConversationHistory() },
                onOpenSettings = { viewModel.openSettings() }
            )

            // CENTER REACTOR & SCROLLABLE COMMAND WORKSPACE
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(8.dp))

                // ARC REACTOR VISUALIZER (Center of Iron Man HUD)
                ArcReactorView(
                    assistantState = assistantState,
                    audioRms = audioRms,
                    size = 230.dp,
                    modifier = Modifier.testTag("arc_reactor_visualizer")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // WAKE WORD QUICK TOGGLE & PULSE RADAR
                WakeWordHeroBadge(
                    isActive = isWakeWordActive,
                    isListening = isWakeWordListening,
                    onToggle = { viewModel.toggleWakeWord() }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // STATUS TELEMETRY BANNER (Listening / Processing / Speaking / Standby)
                StatusTelemetryBanner(
                    state = assistantState,
                    partialSpeech = partialSpeech
                )

                // EXECUTED ACTION CARD (If command was handled)
                if (lastExecutedAction != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    ActionExecutionCard(
                        action = lastExecutedAction!!,
                        onTriggerAgain = { viewModel.triggerActionAgain() }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // LATEST CONVERSATION CARD
                ConversationDisplayCard(
                    userPrompt = latestUserPrompt,
                    jarvisResponse = latestJarvisResponse,
                    state = assistantState,
                    onReplay = { viewModel.replayAudio(latestJarvisResponse) },
                    onStopSpeaking = { viewModel.stopSpeaking() }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // A-TO-Z COMMANDS & DIRECT SHORTCUT DECK (WhatsApp, Apps, Torch, etc.)
                QuickActionDeck(
                    onCommandSelect = { cmd -> viewModel.processUserQuery(cmd) },
                    onSendWhatsApp = { msg, phone -> viewModel.sendWhatsAppDirect(msg, phone) }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // VOICE COMMANDS INSPIRATION CHIPS
                VoiceCommandInspirationChips(
                    onSelectCommand = { cmd -> viewModel.processUserQuery(cmd) }
                )

                Spacer(modifier = Modifier.height(8.dp))
            }

            // BOTTOM CONTROL DECK (Mic button, keyboard switcher, and send)
            BottomControlDeck(
                assistantState = assistantState,
                showTextInput = showTextInput,
                typedQuery = typedQuery,
                onQueryChange = { typedQuery = it },
                onSendTyped = {
                    if (typedQuery.isNotBlank()) {
                        viewModel.processUserQuery(typedQuery)
                        typedQuery = ""
                        showTextInput = false
                    }
                },
                onToggleKeyboard = { showTextInput = !showTextInput },
                onMicClick = {
                    onRequireAudioPermission()
                    viewModel.onMicClicked()
                },
                micButtonColor = micButtonColor,
                pulseScale = if (assistantState != AssistantState.STANDBY) buttonGlowPulse else 1f
            )
        }
        }
    }

    // SETTINGS MODAL
    if (isSettingsOpen) {
        SettingsDialog(
            currentApiKey = viewModel.preferences.customApiKey,
            autoListen = viewModel.preferences.autoListenHandsFree,
            wakeWord = viewModel.preferences.wakeWordEnabled,
            currentPitch = viewModel.preferences.voicePitch,
            currentSpeed = viewModel.preferences.voiceSpeed,
            onSave = { key, autoListen, wakeWord, pitch, speed ->
                viewModel.saveSettings(key, autoListen, wakeWord, pitch, speed)
            },
            onTestVoice = { _, _ ->
                viewModel.testVoice()
            },
            onDismiss = { viewModel.closeSettings() }
        )
    }

    // CONVERSATION HISTORY MODAL
    if (isHistoryOpen) {
        ConversationHistoryDialog(
            messages = chatHistory,
            onReplayAudio = { text -> viewModel.replayAudio(text) },
            onClearHistory = { viewModel.clearChatHistory() },
            onDismiss = { viewModel.toggleConversationHistory() }
        )
    }
}

@Composable
private fun TopHudHeader(
    assistantState: AssistantState,
    hasApiKey: Boolean,
    chatCount: Int,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "header_led_pulse")
    val ledAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "led_alpha"
    )

    val activeStateColor = when (assistantState) {
        AssistantState.STANDBY -> JarvisCyan
        AssistantState.LISTENING -> JarvisGreen
        AssistantState.PROCESSING -> JarvisGold
        AssistantState.SPEAKING -> JarvisCyanBright
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.2.dp, activeStateColor.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .background(JarvisSurfaceDark.copy(alpha = 0.95f), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // System Title & Telemetry Status
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(activeStateColor.copy(alpha = ledAlpha))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "J.A.R.V.I.S. // MK-85 COMMAND CORE",
                    color = JarvisCyanBright,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp,
                    letterSpacing = 0.8.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "A-TO-Z COMMANDS",
                    color = JarvisGreen,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "• HINDI FEMALE AI",
                    color = JarvisTextSecondary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (hasApiKey) "• GEMINI ONLINE" else "• SMART OFFLINE",
                    color = if (hasApiKey) JarvisCyan else JarvisGold,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // Action Buttons
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onOpenHistory,
                modifier = Modifier.size(36.dp).testTag("open_history_button")
            ) {
                BadgedBox(
                    badge = {
                        if (chatCount > 1) {
                            Badge(containerColor = JarvisCyan, contentColor = Color.Black) {
                                Text(chatCount.toString(), fontSize = 9.sp)
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Chat,
                        contentDescription = "Conversation Logs",
                        tint = JarvisCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.size(36.dp).testTag("open_settings_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = JarvisTextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun WakeWordHeroBadge(
    isActive: Boolean,
    isListening: Boolean,
    onToggle: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wake_badge_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(750, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "wake_alpha"
    )

    val badgeBorderColor = if (isActive) JarvisGold.copy(alpha = if (isListening) pulseAlpha else 0.7f) else JarvisSurfaceBorder
    val badgeBg = if (isActive) JarvisGold.copy(alpha = 0.12f) else JarvisSurfaceDark.copy(alpha = 0.8f)

    Row(
        modifier = Modifier
            .border(1.2.dp, badgeBorderColor, RoundedCornerShape(18.dp))
            .background(badgeBg, RoundedCornerShape(18.dp))
            .clickable { onToggle() }
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag("wake_word_badge"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(9.dp)
                .clip(CircleShape)
                .background(
                    if (isActive && isListening) JarvisGold.copy(alpha = pulseAlpha)
                    else if (isActive) JarvisGold
                    else JarvisTextMuted
                )
        )
        Spacer(modifier = Modifier.width(8.dp))
        Icon(
            imageVector = Icons.Default.Bolt,
            contentDescription = null,
            tint = if (isActive) JarvisGold else JarvisTextMuted,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = if (isActive) "वेक वर्ड: 'Hey Jarvis' सक्रिय" else "वेक वर्ड: 'Hey Jarvis' बंद",
            color = if (isActive) JarvisCyanBright else JarvisTextSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = if (isActive) "• बोलें 'Hey Jarvis'" else "• चालू करने के लिए टैप करें",
            color = if (isActive) JarvisGold else JarvisCyan,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun StatusTelemetryBanner(
    state: AssistantState,
    partialSpeech: String
) {
    val infiniteTransition = rememberInfiniteTransition(label = "banner_anim")
    val bannerPulse by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "banner_pulse"
    )

    val stateText = when (state) {
        AssistantState.STANDBY -> "प्रतीक्षा में (STANDBY) • कोई भी कमांड बोलें"
        AssistantState.LISTENING -> "सुन रही हूँ… बोलिए (LISTENING)"
        AssistantState.PROCESSING -> "कमांड निष्पादन व विश्लेषण जारी है… (EXECUTING)"
        AssistantState.SPEAKING -> "उत्तर दे रही हूँ… (SPEAKING)"
    }

    val stateColor = when (state) {
        AssistantState.STANDBY -> JarvisCyan
        AssistantState.LISTENING -> JarvisGreen
        AssistantState.PROCESSING -> JarvisGold
        AssistantState.SPEAKING -> JarvisCyanBright
    }

    val glowAlpha = if (state != AssistantState.STANDBY) bannerPulse else 0.45f

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .background(stateColor.copy(alpha = 0.14f), RoundedCornerShape(20.dp))
                .border(1.5.dp, stateColor.copy(alpha = glowAlpha), RoundedCornerShape(20.dp))
                .padding(horizontal = 14.dp, vertical = 5.dp)
        ) {
            Icon(
                imageVector = when (state) {
                    AssistantState.STANDBY -> Icons.Default.CheckCircle
                    AssistantState.LISTENING -> Icons.Default.Mic
                    AssistantState.PROCESSING -> Icons.Default.GraphicEq
                    AssistantState.SPEAKING -> Icons.AutoMirrored.Filled.VolumeUp
                },
                contentDescription = null,
                tint = stateColor,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = stateText,
                color = stateColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace
            )
        }

        if (partialSpeech.isNotBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "“$partialSpeech”",
                color = JarvisTextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun ConversationDisplayCard(
    userPrompt: String,
    jarvisResponse: String,
    state: AssistantState,
    onReplay: () -> Unit,
    onStopSpeaking: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, JarvisSurfaceBorder, RoundedCornerShape(14.dp))
            .testTag("conversation_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = JarvisSurfaceCard)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // User query section
            if (userPrompt.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "आप (COMMAND):",
                        color = JarvisElectricBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = userPrompt,
                    color = JarvisTextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(JarvisSurfaceBorder)
                )
                Spacer(modifier = Modifier.height(10.dp))
            }

            // JARVIS response section
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "JARVIS:",
                        color = JarvisCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "महिला स्वर",
                        color = JarvisTextMuted,
                        fontSize = 10.sp
                    )

                    // Waveform equalizer bars indicator when speaking
                    if (state == AssistantState.SPEAKING) {
                        Spacer(modifier = Modifier.width(8.dp))
                        SpeakingAudioEqualizer()
                    }
                }

                Row {
                    if (state == AssistantState.SPEAKING) {
                        IconButton(
                            onClick = onStopSpeaking,
                            modifier = Modifier
                                .size(28.dp)
                                .background(JarvisRed.copy(alpha = 0.2f), CircleShape)
                                .testTag("stop_speaking_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stop,
                                contentDescription = "Stop",
                                tint = JarvisRed,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    IconButton(
                        onClick = onReplay,
                        modifier = Modifier
                            .size(28.dp)
                            .background(JarvisCyan.copy(alpha = 0.15f), CircleShape)
                            .testTag("replay_audio_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Replay Speech",
                            tint = JarvisCyan,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = jarvisResponse,
                color = JarvisTextPrimary,
                fontSize = 14.sp,
                lineHeight = 21.sp
            )
        }
    }
}

@Composable
private fun SpeakingAudioEqualizer() {
    val infiniteTransition = rememberInfiniteTransition(label = "eq_bars")
    val bar1 by infiniteTransition.animateFloat(
        initialValue = 4f,
        targetValue = 16f,
        animationSpec = infiniteRepeatable(tween(260), RepeatMode.Reverse),
        label = "b1"
    )
    val bar2 by infiniteTransition.animateFloat(
        initialValue = 14f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(tween(200), RepeatMode.Reverse),
        label = "b2"
    )
    val bar3 by infiniteTransition.animateFloat(
        initialValue = 6f,
        targetValue = 18f,
        animationSpec = infiniteRepeatable(tween(310), RepeatMode.Reverse),
        label = "b3"
    )
    val bar4 by infiniteTransition.animateFloat(
        initialValue = 15f,
        targetValue = 7f,
        animationSpec = infiniteRepeatable(tween(220), RepeatMode.Reverse),
        label = "b4"
    )
    val bar5 by infiniteTransition.animateFloat(
        initialValue = 5f,
        targetValue = 14f,
        animationSpec = infiniteRepeatable(tween(280), RepeatMode.Reverse),
        label = "b5"
    )

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Box(modifier = Modifier.width(2.5.dp).height(bar1.dp).background(JarvisCyanBright, RoundedCornerShape(1.dp)))
        Box(modifier = Modifier.width(2.5.dp).height(bar2.dp).background(JarvisGreen, RoundedCornerShape(1.dp)))
        Box(modifier = Modifier.width(2.5.dp).height(bar3.dp).background(JarvisCyan, RoundedCornerShape(1.dp)))
        Box(modifier = Modifier.width(2.5.dp).height(bar4.dp).background(JarvisGold, RoundedCornerShape(1.dp)))
        Box(modifier = Modifier.width(2.5.dp).height(bar5.dp).background(JarvisCyanBright, RoundedCornerShape(1.dp)))
    }
}

@Composable
private fun VoiceCommandInspirationChips(
    onSelectCommand: (String) -> Unit
) {
    val commands = listOf(
        "💬 WhatsApp पे Hello msg bhejo",
        "🎬 YouTube kholo",
        "🔦 Torch chalu karo",
        "📷 Camera open karo",
        "🧭 Delhi ka rasta dikhao",
        "⏰ Subah 7 baje ka alarm lagao",
        "🧮 500 * 25 kitna hoga",
        "📞 198 par call lagao",
        "🔍 Google par search karo AI news",
        "✨ Ek prernadayak vichar sunao"
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "आवाज कमांड्स के उदाहरण (A-TO-Z COMMAND PROMPTS):",
            color = JarvisTextMuted,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp,
            modifier = Modifier.padding(horizontal = 2.dp, vertical = 2.dp)
        )

        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (cmd in commands) {
                Box(
                    modifier = Modifier
                        .background(
                            Brush.horizontalGradient(
                                listOf(JarvisSurfaceDark, JarvisCyan.copy(alpha = 0.08f))
                            ),
                            RoundedCornerShape(16.dp)
                        )
                        .border(1.2.dp, JarvisCyan.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                        .clickable { onSelectCommand(cmd) }
                        .padding(horizontal = 11.dp, vertical = 7.dp)
                        .testTag("command_prompt_chip")
                ) {
                    Text(
                        text = cmd,
                        color = JarvisCyanBright,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
private fun BottomControlDeck(
    assistantState: AssistantState,
    showTextInput: Boolean,
    typedQuery: String,
    onQueryChange: (String) -> Unit,
    onSendTyped: () -> Unit,
    onToggleKeyboard: () -> Unit,
    onMicClick: () -> Unit,
    micButtonColor: Color,
    pulseScale: Float
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val keyboardController = LocalSoftwareKeyboardController.current
        // Optional Text Input Field for quiet environments
        AnimatedVisibility(
            visible = showTextInput,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = typedQuery,
                    onValueChange = onQueryChange,
                    placeholder = {
                        Text(
                            "जार्विस को कमांड दें (उदा: whatsapp pe msg bhejo)...",
                            color = JarvisTextMuted,
                            fontSize = 12.sp
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("typed_query_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = JarvisCyan,
                        unfocusedBorderColor = JarvisSurfaceBorder,
                        focusedTextColor = JarvisTextPrimary,
                        unfocusedTextColor = JarvisTextPrimary,
                        focusedContainerColor = JarvisSurfaceCard,
                        unfocusedContainerColor = JarvisSurfaceCard
                    ),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            keyboardController?.hide()
                            onSendTyped()
                        }
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        keyboardController?.hide()
                        onSendTyped()
                    },
                    modifier = Modifier
                        .size(46.dp)
                        .background(JarvisCyan, RoundedCornerShape(12.dp))
                        .testTag("send_typed_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send",
                        tint = Color.Black
                    )
                }
            }
        }

        // Action controls row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Keyboard toggle
            IconButton(
                onClick = onToggleKeyboard,
                modifier = Modifier
                    .size(44.dp)
                    .background(JarvisSurfaceCard, CircleShape)
                    .border(1.dp, JarvisSurfaceBorder, CircleShape)
                    .testTag("toggle_keyboard_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Keyboard,
                    contentDescription = "Toggle Keyboard",
                    tint = if (showTextInput) JarvisCyan else JarvisTextSecondary
                )
            }

            // PRIMARY GLOWING ARC MIC BUTTON
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(80.dp)
                    .scale(pulseScale)
            ) {
                // Outermost glowing aura
                Box(
                    modifier = Modifier
                        .size(78.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    micButtonColor.copy(alpha = 0.45f),
                                    micButtonColor.copy(alpha = 0.1f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                // Outer border ring
                Box(
                    modifier = Modifier
                        .size(66.dp)
                        .clip(CircleShape)
                        .border(BorderStroke(2.dp, micButtonColor), CircleShape)
                        .background(JarvisSurfaceDark)
                )

                // Center glowing button
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    micButtonColor,
                                    micButtonColor.copy(alpha = 0.75f)
                                )
                            )
                        )
                        .clickable { onMicClick() }
                        .testTag("jarvis_mic_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (assistantState) {
                            AssistantState.SPEAKING -> Icons.Default.Stop
                            AssistantState.LISTENING -> Icons.Default.Mic
                            AssistantState.PROCESSING -> Icons.Default.GraphicEq
                            AssistantState.STANDBY -> Icons.Default.Mic
                        },
                        contentDescription = "JARVIS Mic",
                        tint = if (assistantState == AssistantState.SPEAKING) JarvisRed else Color.Black,
                        modifier = Modifier.size(26.dp)
                    )
                }
            }

            // Mute / Standby toggle
            IconButton(
                onClick = onMicClick,
                modifier = Modifier
                    .size(44.dp)
                    .background(JarvisSurfaceCard, CircleShape)
                    .border(1.dp, JarvisSurfaceBorder, CircleShape)
                    .testTag("mute_standby_button")
            ) {
                Icon(
                    imageVector = if (assistantState == AssistantState.LISTENING) Icons.Default.MicOff else Icons.Default.GraphicEq,
                    contentDescription = "Mute or Status",
                    tint = JarvisTextSecondary
                )
            }
        }
    }
}
