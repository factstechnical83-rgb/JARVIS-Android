package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.JarvisCyan
import com.example.ui.theme.JarvisCyanBright
import com.example.ui.theme.JarvisGold
import com.example.ui.theme.JarvisGreen
import com.example.ui.theme.JarvisSurfaceBorder
import com.example.ui.theme.JarvisSurfaceCard
import com.example.ui.theme.JarvisSurfaceDark
import com.example.ui.theme.JarvisTextMuted
import com.example.ui.theme.JarvisTextPrimary
import com.example.ui.theme.JarvisTextSecondary

@Composable
fun SettingsDialog(
    currentApiKey: String,
    autoListen: Boolean,
    wakeWord: Boolean,
    currentPitch: Float,
    currentSpeed: Float,
    onSave: (apiKey: String, autoListen: Boolean, wakeWord: Boolean, pitch: Float, speed: Float) -> Unit,
    onTestVoice: (pitch: Float, speed: Float) -> Unit,
    onDismiss: () -> Unit
) {
    var apiKeyText by remember { mutableStateOf(currentApiKey) }
    var autoListenState by remember { mutableStateOf(autoListen) }
    var wakeWordState by remember { mutableStateOf(wakeWord) }
    var pitchState by remember { mutableFloatStateOf(currentPitch) }
    var speedState by remember { mutableFloatStateOf(currentSpeed) }
    val keyboardController = LocalSoftwareKeyboardController.current

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.2.dp, JarvisCyan.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .testTag("settings_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = JarvisSurfaceDark)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = null,
                            tint = JarvisCyan,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "जार्विस सेटिंग्स // CONFIG",
                            color = JarvisCyanBright,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("settings_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = JarvisTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // WAKE WORD SECTION
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (wakeWordState) JarvisCyan.copy(alpha = 0.12f) else JarvisSurfaceCard,
                            RoundedCornerShape(10.dp)
                        )
                        .border(
                            1.dp,
                            if (wakeWordState) JarvisCyan.copy(alpha = 0.6f) else JarvisSurfaceBorder,
                            RoundedCornerShape(10.dp)
                        )
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = if (wakeWordState) JarvisGold else JarvisTextMuted,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "वेक वर्ड: 'Hey Jarvis' / 'Hello Jarvis'",
                                color = if (wakeWordState) JarvisCyanBright else JarvisTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "बिना टच किए 'Hey Jarvis' बोलकर सीधे बात करें",
                                color = JarvisTextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }
                    Switch(
                        checked = wakeWordState,
                        onCheckedChange = { wakeWordState = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = JarvisCyanBright,
                            checkedTrackColor = JarvisCyan.copy(alpha = 0.35f),
                            uncheckedThumbColor = JarvisTextMuted,
                            uncheckedTrackColor = JarvisSurfaceBorder
                        ),
                        modifier = Modifier.testTag("wake_word_switch")
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Female Voice Pitch & Realistic Cadence Section
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.RecordVoiceOver,
                        contentDescription = null,
                        tint = JarvisCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "यथार्थवादी महिला हिंदी आवाज़ (Realistic Female Voice)",
                        color = JarvisCyan,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Quick presets for realistic female voice
                Text(
                    text = "त्वरित वॉइस प्रोफाइल (Presets):",
                    color = JarvisTextMuted,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    VoicePresetChip(
                        label = "नेचुरल (1.08x)",
                        isSelected = Math.abs(pitchState - 1.08f) < 0.02f && Math.abs(speedState - 0.98f) < 0.02f,
                        onClick = {
                            pitchState = 1.08f
                            speedState = 0.98f
                        }
                    )
                    VoicePresetChip(
                        label = "स्वीट (1.12x)",
                        isSelected = Math.abs(pitchState - 1.12f) < 0.02f && Math.abs(speedState - 1.00f) < 0.02f,
                        onClick = {
                            pitchState = 1.12f
                            speedState = 1.00f
                        }
                    )
                    VoicePresetChip(
                        label = "सॉफ्ट (1.04x)",
                        isSelected = Math.abs(pitchState - 1.04f) < 0.02f && Math.abs(speedState - 0.95f) < 0.02f,
                        onClick = {
                            pitchState = 1.04f
                            speedState = 0.95f
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Pitch Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("स्वर तीखापन (Pitch)", color = JarvisTextSecondary, fontSize = 12.sp)
                    Text(
                        text = String.format("%.2fx", pitchState),
                        color = JarvisGold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Slider(
                    value = pitchState,
                    onValueChange = { pitchState = it },
                    valueRange = 0.95f..1.30f,
                    colors = SliderDefaults.colors(
                        thumbColor = JarvisCyan,
                        activeTrackColor = JarvisCyan,
                        inactiveTrackColor = JarvisSurfaceBorder
                    ),
                    modifier = Modifier.testTag("pitch_slider")
                )

                // Speed Slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("बोलने की गति (Speech Rate)", color = JarvisTextSecondary, fontSize = 12.sp)
                    Text(
                        text = String.format("%.2fx", speedState),
                        color = JarvisGold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Slider(
                    value = speedState,
                    onValueChange = { speedState = it },
                    valueRange = 0.85f..1.20f,
                    colors = SliderDefaults.colors(
                        thumbColor = JarvisCyan,
                        activeTrackColor = JarvisCyan,
                        inactiveTrackColor = JarvisSurfaceBorder
                    ),
                    modifier = Modifier.testTag("speed_slider")
                )

                // Test Voice Button
                OutlinedButton(
                    onClick = { onTestVoice(pitchState, speedState) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("test_voice_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisCyan),
                    border = androidx.compose.foundation.BorderStroke(1.dp, JarvisCyan.copy(alpha = 0.7f))
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("महिला आवाज़ सुनें (Test Voice)")
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Hands-free Auto-Listen Mode
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(JarvisSurfaceCard, RoundedCornerShape(8.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "हैंड्स-फ्री निरंतर बातचीत (Continuous)",
                            color = JarvisTextPrimary,
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "उत्तर समाप्त होने पर अपने आप पुनः सुनें",
                            color = JarvisTextMuted,
                            fontSize = 10.sp
                        )
                    }
                    Switch(
                        checked = autoListenState,
                        onCheckedChange = { autoListenState = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = JarvisCyan,
                            checkedTrackColor = JarvisCyan.copy(alpha = 0.3f),
                            uncheckedThumbColor = JarvisTextMuted,
                            uncheckedTrackColor = JarvisSurfaceBorder
                        ),
                        modifier = Modifier.testTag("auto_listen_switch")
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Free API Key Section
                Text(
                    text = "Google AI Studio API Key (वैकल्पिक / Optional)",
                    color = JarvisTextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "aistudio.google.com से निःशुल्क प्राप्त करें। खाली छोड़ने पर सिस्टम डिफ़ॉल्ट काम करेगा।",
                    color = JarvisTextMuted,
                    fontSize = 11.sp,
                    lineHeight = 14.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = apiKeyText,
                    onValueChange = { apiKeyText = it },
                    placeholder = {
                        Text(
                            "AIzaSy...",
                            color = JarvisTextMuted,
                            fontSize = 12.sp
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("api_key_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = JarvisCyan,
                        unfocusedBorderColor = JarvisSurfaceBorder,
                        focusedTextColor = JarvisTextPrimary,
                        unfocusedTextColor = JarvisTextPrimary,
                        focusedContainerColor = JarvisSurfaceCard,
                        unfocusedContainerColor = JarvisSurfaceCard
                    ),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            keyboardController?.hide()
                        }
                    ),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = JarvisTextSecondary),
                        border = androidx.compose.foundation.BorderStroke(1.dp, JarvisSurfaceBorder),
                        modifier = Modifier.testTag("settings_cancel_button")
                    ) {
                        Text("रद्द करें")
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = {
                            onSave(apiKeyText, autoListenState, wakeWordState, pitchState, speedState)
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = JarvisCyan,
                            contentColor = Color.Black
                        ),
                        modifier = Modifier.testTag("settings_save_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("सुरक्षित करें", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun VoicePresetChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .border(
                1.dp,
                if (isSelected) JarvisCyan else JarvisSurfaceBorder,
                RoundedCornerShape(6.dp)
            )
            .background(
                if (isSelected) JarvisCyan.copy(alpha = 0.2f) else JarvisSurfaceCard,
                RoundedCornerShape(6.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 5.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) JarvisCyanBright else JarvisTextSecondary,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
