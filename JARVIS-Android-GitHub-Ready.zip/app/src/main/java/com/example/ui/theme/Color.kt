package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sci-Fi JARVIS Arc Reactor & Cyber HUD Palette
val JarvisBackground = Color(0xFF070B14)
val JarvisSurfaceDark = Color(0xFF0D1424)
val JarvisSurfaceCard = Color(0xFF131D33)
val JarvisSurfaceBorder = Color(0xFF1F3155)

val JarvisCyan = Color(0xFF00F0FF)
val JarvisCyanBright = Color(0xFF5FF8FF)
val JarvisCyanMuted = Color(0xFF008B99)
val JarvisBlue = Color(0xFF0077FE)
val JarvisElectricBlue = Color(0xFF29B6F6)

val JarvisGold = Color(0xFFFFD700)
val JarvisGreen = Color(0xFF00FF9D)
val JarvisRed = Color(0xFFFF3366)

val JarvisTextPrimary = Color(0xFFF0F8FF)
val JarvisTextSecondary = Color(0xFF8FA8CD)
val JarvisTextMuted = Color(0xFF556F94)

val ArcReactorCoreGlow = Color(0x6600F0FF)
val ArcReactorOuterRing = Color(0x3300F0FF)
